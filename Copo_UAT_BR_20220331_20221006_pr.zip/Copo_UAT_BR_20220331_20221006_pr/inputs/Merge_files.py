import pandas as pd
import argparse
import platform
from datetime import datetime
import logging
import numpy as np

if __name__=='__main__':

    logPath = "/PMC/FVA/log/"
    if platform.system() == "Windows":
        logPath = ""

    parser = argparse.ArgumentParser()
    parser.add_argument("--unit")
    parser.add_argument("--date")
    args = parser.parse_args()

    #logFile = "prueba"
    #logging.basicConfig(filename=logFile, level=logging.INFO, format='%(levelname)s - %(asctime)s - %(message)s')

    try:
        df1 = pd.read_csv('fvaava_trade_details_bond_' + args.unit + '_' + args.date + '.csv', sep=';', engine='python')
    except:
        df1 = pd.DataFrame(columns = ["security_code", "country_code", "book", "portfolio", "instrument", "security_currency",
                                "issuer", "nominal_unit", "maturity", "price", "lot_size", "capital_factor", "nominal_calc",
                                "quantity_calc", "prod_type"])
    try:
        df3 = pd.read_csv('fvaava_trade_details_abs_' + args.unit + '_' + args.date + '.csv', sep=';', engine='python')
    except:
        df3 = pd.DataFrame(columns = ["security_code", "country_code", "book", "portfolio", "instrument", "security_currency",
                           "issuer", "nominal_unit", "maturity", "price", "lot_size", "capital_factor", "nominal_calc",
                           "quantity_calc", "prod_type"])

    try:
        df2 = pd.read_csv('BUCKETS_BONDS_FRTB_' + args.unit + '_' + args.date + '.csv', sep=';', engine='python')
    except:
        df2 = pd.DataFrame(columns=["isin", "maturity", "bb_dx533_is_covered", "bb_ds530_defaulted", "GLCS", "rating_external_normalized","RESA_issue_normalized",
                                    "rating_pari_passu_emisor_normalized", "prod_type", "country", "bb_ds674_security_type"])

    try:
        df4 = pd.read_csv('ISSUERS_GLOBAL_' + args.date + '.csv', sep=';', engine='python')
        df4 = df4.rename(columns={'Country': 'country'})
    except:
        df4 = pd.DataFrame(columns=["GLCS", "Industry_group", "country"])
    try:
        df5 = pd.read_csv('BUCKETS_SEC_FRTB_' + args.date + '.csv', sep=';', engine='python')
        df5 = df5.rename(columns={'Isin': 'isin', 'Maturity': 'maturity', 'Country': 'country',
                                  'rating_pari_passu normalizado': 'rating_pari_passu_emisor_normalized'})
    except:
        df5 = pd.DataFrame(columns=["isin", "maturity", "bb_dx533_is_covered", "bb_ds530_defaulted", "GLCS", "rating_external_normalized","RESA_issue_normalized",
                                    "rating_pari_passu_emisor_normalized", "prod_type", "country", "bb_ds674_security_type"])

    df2['prod_type'] = 'BOND'
    df5['prod_type'] = 'ABS'
    df1 = pd.concat([df1, df3], axis=0, ignore_index=True)

    df1 = df1.rename(columns={'maturity': 'maturity_td', 'prod_type' : 'prod_type_td'})



    statics_bonds = pd.merge(df2[["isin", "maturity", "bb_dx533_is_covered", "bb_ds530_defaulted", "GLCS", "rating_external_normalized","RESA_issue_normalized","rating_pari_passu_emisor_normalized", "prod_type"]], df1[["security_code", "maturity_td", "issuer", "security_currency", "price", "prod_type_td", "instrument"]], how='left', left_on = "isin", right_on = "security_code")
    statics_bonds = statics_bonds.drop('security_code', 1)
    statics_bonds = pd.merge(statics_bonds, df4[["GLCS", "Industry_group", "country"]], how='left', on = "GLCS")

    statics_abs = pd.merge(df5[["isin", "maturity", "country", "bb_dx533_is_covered", "bb_ds530_defaulted", "GLCS", "rating_external_normalized","RESA_issue_normalized","rating_pari_passu_emisor_normalized","prod_type","bb_ds674_security_type"]], df1[["security_code", "maturity_td", "issuer", "security_currency", "price", "prod_type_td", "instrument"]], how='left', left_on = "isin", right_on = "security_code")
    statics_abs = statics_abs.drop('security_code', 1)
    statics_abs = pd.merge(statics_abs, df4[["GLCS", "Industry_group"]], how='left', on="GLCS")

    statics = pd.concat([statics_bonds,statics_abs], axis=0, ignore_index=True)
    statics = statics.drop_duplicates()

    trade_details = pd.merge(df1[["security_code", "country_code", "book", "portfolio", "instrument", "security_currency", "issuer", "nominal_unit", "maturity_td", "price", "lot_size", "capital_factor", "nominal_calc", "quantity_calc", "prod_type_td"]],statics[["isin", "country", "bb_dx533_is_covered", "bb_ds530_defaulted", "Industry_group", "maturity", "rating_external_normalized","RESA_issue_normalized","rating_pari_passu_emisor_normalized", "prod_type","bb_ds674_security_type"]], how='left', left_on = "security_code", right_on = "isin")
    trade_details = trade_details.drop("isin", 1)
    #trade_details = trade_details.drop_duplicates()
    trade_details[["prod_type"]] = np.where(trade_details[["prod_type"]].isnull(), trade_details[["prod_type_td"]], trade_details[["prod_type"]])
    trade_details[["prod_type"]] = trade_details[["prod_type"]].fillna("BOND")
    trade_details = trade_details.drop("prod_type_td", 1)
    trade_details = trade_details.drop_duplicates()

    print("va a imprimir")
    
    trade_details.to_csv("fvaava_trade_details_global_" + args.unit + '_' + args.date + ".csv", index=False, sep=';')
    statics.to_csv("fva_statics_bond_abs_" + args.unit + '_' + args.date + ".csv", index=False, sep=';')







