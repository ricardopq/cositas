# -*- coding: utf-8 -*-
"""
Created on Tue Jan 21 11:47:24 2020

@author: cdasi
"""

import pandas as pd
import numpy as np
import warnings
import re

# def group_by_bucket(df, bucket_list, group_by_values, percentile, agg_dict):
#     '''
#     Support function which allows us to generate the group by dataframe per group of buckets.
#     '''
#     df_gb = df.groupby(by=[bucket_list[0]], as_index=False).agg(agg_dict)
    
#     buckets = [bucket_list[0]]
#     df_gb.loc[:, 'key'] = generate_key(df_gb, buckets)
    
#     df_gb.drop(columns=bucket_list[0], inplace=True)

#     for bucket in bucket_list[1:]:
#         buckets.append(bucket)
        
#         df_gb_temp = df.groupby(by=buckets, as_index=False).agg(agg_dict)
#         df_gb_temp.loc[:, 'key'] = generate_key(df_gb_temp, buckets)
        
#         df_gb_temp.drop(columns=buckets, inplace=True)
        
#         df_gb = pd.concat([df_gb, df_gb_temp])
    
#     if percentile is None:
#         df_gb.rename(columns={column:column+"_mean" for column in group_by_values}, inplace=True)
# #        pass
#     elif type(percentile)==float or type(percentile)==int:
#         df_gb.rename(columns={column:column+"_P"+str(int(percentile*100)) for column in group_by_values}, inplace=True)
    
#     return df_gb


def group_by_bucket(df, bucket_list, group_by_values, percentile, agg_dict):
    '''
    Support function which allows us to generate the group by dataframe per group of buckets.
    '''
    df_gb = df.groupby(by=[bucket_list[0]], as_index=False).agg(agg_dict)
    
    buckets = [bucket_list[0]]
    df_gb['key'] = generate_key(df_gb, buckets)
    
    df_gb.drop(columns=bucket_list[0], inplace=True)

    for bucket in bucket_list[1:]:
        buckets.append(bucket)
        
        df_gb_temp = df.groupby(by=buckets, as_index=False).agg(agg_dict)
        df_gb_temp['key'] = generate_key(df_gb_temp, buckets)
        
        df_gb_temp.drop(columns=buckets, inplace=True)
        
        df_gb = pd.concat([df_gb, df_gb_temp])
    
    if percentile is None:
        df_gb.rename(columns={column:column+"_mean" for column in group_by_values}, inplace=True)
#        pass
    elif type(percentile)==float or type(percentile)==int:
        df_gb.rename(columns={column:column+"_P"+str(int(percentile*100)) for column in group_by_values}, inplace=True)
    
    return df_gb


# def generate_key(df, bucket_list):
#     '''
#     With this function we generate the key by concatenating string values of the columns given in bucket_list.
    
#     Parameters
#     ----------
#         df : Pandas dataframe
#             Must have the columns defined in bucket_list. This is the dataframe with which the key values will be generated after.
#         bucket_list : List
#             List of columns to use for generating the key values
    
#     Returns
#     -------
#         key : Pandas series
#             Conctatenated key
#     '''
#     if type(bucket_list)==list:
#         key = df[bucket_list[0]]
#         for col in bucket_list[1:]:
#             key = key + '-' + df[col]
#     elif type(bucket_list)==str:
#         key = df[bucket_list]
        
#     return key


def generate_key(df, bucket_list):
    '''
    With this function we generate the key by concatenating string values of the columns given in bucket_list.
    
    Parameters
    ----------
        df : Pandas dataframe
            Must have the columns defined in bucket_list. This is the dataframe with which the key values will be generated after.
        bucket_list : List
            List of columns to use for generating the key values
    
    Returns
    -------
        key : Pandas series
            Conctatenated key
    '''
    if type(bucket_list)==list:
        key = df[bucket_list[0]]
        for col in bucket_list[1:]:
            key = key + '-' + df[col]
    elif type(bucket_list)==str:
        key = df[bucket_list]
        
    return key


def generate_agg_dict(group_by_values, percentile_level, omit_nans):
    '''
    Support function which defines the dictionary which will be used for generating the grouped by dataframe
    '''
    if percentile_level:
        if omit_nans:
            agg_dict = {group_by_value: [lambda x: np.nanquantile(x, q=percentile_level), 'count'] for group_by_value in group_by_values}
        else:
            agg_dict = {group_by_value: [lambda x: np.quantile(x, q=percentile_level), 'count'] for group_by_value in group_by_values}
    else:
        # Si entra aquí, es porque percentile level es None, y por tanto hacemos la media.
        if omit_nans:
            agg_dict = {group_by_value: [lambda x: np.nanmean(x), 'count'] for group_by_value in group_by_values}
        else:
            agg_dict = {group_by_value: [lambda x: np.mean(x), 'count'] for group_by_value in group_by_values}
            
    return agg_dict

def group_by_proxy(df, df_proxy, bucket_list, group_by_values, percentile_level=None, omit_nans=True, omit_zeros=True, print_steps=True):
    '''
    With this function we group by a set of keys defined in bucket list in order to calculate the percentile levels of the group_by_values columns
    
    Parameters
    ----------
        df : Pandas dataframe
            Must have the columns defined in bucket_list. This is the dataframe with which the key values will be generated after, and which will be grouped by.
        df_proxy : Pandas dataframe
            The pool values which will be used for filling the missing data values. Must have the columns defined in bucket_list.
        bucket_list : List
            List of columns to use for generating the key values
        group_by_values : List
            List of columns to use for aggregating when calculating the percentile or mean
        percentile_level : List, integer or None, default None
            Levels at which the percentile of the values defined in group_by_values will be calculated, and if None, an average will be calculated
            instead
        omit_nans : Boolean, default True
            Wether to consider the nan values when calculating the percentile or not
        omit_zeros : Boolean, default True
            Wehther to take into account zero values in the sample for generating the proxies or not. omit_nans MUST be True for this instance to
            be effective. For instance, when performing the mean/percentile of list [100, 200, 90, 0, 100, 0, 99], consider every value (omit_zeros=False), or 
            consdier instead the values [100, 200, 90, 100, 99] (omit_zeros=True)
        print_steps : Boolean, default True
            Print or not the steps given in in this function
        
    Returns
    -------
        df_gb : Pandas series
            Grouped by dataframe by key and with the group_by_values columns aggregated at different percentile levels
    '''
    
    # Eliminamos los warnings, ya que puede que se lancen los siguientes avisos en consola: 
    #   1.PerformanceWarning: dropping on a non-lexsorted multi-index without a level parameter may impact performance. -Warning de perfomamnce, el cual por la 
    #     por la lógica del código no se puede evitar. 
    #   2.RuntimeWarning: All-NaN slice encountered. -Este error se debe a que no siempre vamos a tener suficientes datos para todas las claves del proxy, 
    #     por lo tanto puede que se este calculado el percentil de un vector de NaNs.
    # Ninguno de estos errores afecta a la ejecución del código
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        
        # Definimos el proxy a usar, donde Bucket_k indica que tenemos que subir "k" fallbacks desde el mínimo nivel. Por ejemplo, si bucket list es
        # 'a', 'b', 'c', 'd', y tenemos un ISIN que está en Bucket_2, quiere decir que hemos tenido que subir al tercer nivel, es decir, que 'c' es vacío.
        df.loc[:, 'Bucket'] = 'Bucket_0'
        df['key'] = generate_key(df, bucket_list = bucket_list)     
        
        bucket_list_ = bucket_list.copy()
        bucket_list_.pop()
        for counter, ix in enumerate(bucket_list[::-1]):
            try:
                # Generates the bucket and defines the key
                df.loc[df[ix].isnull(), 'Bucket'] = 'Bucket_'+str(counter+1)
                df.loc[df[ix].isnull(), 'key'] = generate_key(df.loc[df[ix].isnull(), bucket_list_], bucket_list=bucket_list_)
                bucket_list_.pop()
            except IndexError:
                # If tries to access a non-valid index, meaning that the bucket_list_ is empty, we have gone through every column and we break.
                # This mismatch happens due to performing the first iteration outside of the loop, which we have to do for definition purposes.
                break
        
        df_proxy.loc[:, 'Bucket'] = 'Bucket_0'
        df_proxy['key'] = generate_key(df_proxy, bucket_list = bucket_list)     
        
        bucket_list_ = bucket_list.copy()
        bucket_list_.pop()
        for counter, ix in enumerate(bucket_list[::-1]):
            try:
                # Generates the bucket and defines the key
                df_proxy.loc[df_proxy[ix].isnull(), 'Bucket'] = 'Bucket_'+str(counter+1)
                df_proxy.loc[df_proxy[ix].isnull(), 'key'] = generate_key(df_proxy.loc[df_proxy[ix].isnull(), bucket_list_], bucket_list=bucket_list_)
                bucket_list_.pop()
            except IndexError:
                # If tries to access a non-valid index, meaning that the bucket_list_ is empty, we have gone through every column and we break.
                # This mismatch happens due to performing the first iteration outside of the loop, which we have to do for definition purposes.
                break
        
        # Generamos una copia del fichero df_proxy, ya que si omit_zeros=True, vamos a modificar el dato original, y no queremos eso. La hacemos aquí
        # abajo ya que queremos salvar la key en el dataframe original (cuestiones de debugging)
        df_proxy_ = df_proxy.copy()
        
        if omit_zeros:
            df_proxy_[group_by_values]=df_proxy_[group_by_values].replace(to_replace=0, value=np.nan)
        
        
        if type(percentile_level)==list:
            
            # We define the first functions which will be used to aggregate with the first percentile level. We group by the defined keys and 
            # aggregate after these functions. The result will be a dataframe with 'key', and the columns defined in group_by_values, which we
            # will rename to include a distinction.        
            agg_dict = generate_agg_dict(group_by_values=group_by_values, percentile_level=percentile_level[0], omit_nans=omit_nans)
            df_gb = group_by_bucket(df_proxy_, bucket_list, group_by_values, percentile_level[0], agg_dict)
    
            for percentile in percentile_level[1:]:
                # The process described above is performed through each element of the percentile percentile_level list with a merge to the
                # main dataframe.
                agg_dict = generate_agg_dict(group_by_values=group_by_values, percentile_level=percentile, omit_nans=omit_nans)
                df_gb_temp = group_by_bucket(df_proxy_, bucket_list, group_by_values, percentile, agg_dict)
                
                df_gb = pd.merge(df_gb, df_gb_temp, how='outer', on='key')
    
        elif type(percentile_level)==float or type(percentile_level)==int or percentile_level is None:
            # As the type(percentile_level) is either a float o a number (only one), the same process as above is performed, but only once
            agg_dict = generate_agg_dict(group_by_values=group_by_values, percentile_level=percentile_level, omit_nans=omit_nans)
            df_gb = group_by_bucket(df_proxy_, bucket_list, group_by_values, percentile_level, agg_dict)
        
        col_names = ['_'.join(col).strip() if (not 'key' in col) else 'key' for col in df_gb.columns.values]
        col_names = [col if (not '_<lambda' in col) else re.sub('_<lambda(_\d+){0,1}>', '', col) for col in col_names] #Con este regex eliminamos texto de la forma "_<lambda_X>" y "_<lambda>"
        df_gb.columns = col_names
    
    return df_gb

