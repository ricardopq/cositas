# -*- coding: utf-8 -*-
"""
Created on Mon Jan 20 11:58:37 2020

@author: cdasi
"""

import pandas as pd
import numpy as np
import warnings

def ajuste_AVA(df, exchange_rates, execution_date, market_percentaje=0.25, param_y=1, epsilon=-1, days=10, all_same_currency=False):
    '''
    The following function calculates the ajustment to be made to the passed possitions after a series of given parameters
    previously calculated, if any.
    
    Parameters
    ----------
        df : Pandas dataframe 
            With columns ...
    
    Return
    ----------
        df : Pandas dataframe 
            Inputted with an additional column representing the adjustment to include due to concentration.
    '''
    
    df['market_volume_access']= df['avg_daily_traded_volume'] * df['market_percentaje_santander']
    df['abs_notional']=abs(df.notional)
    
    df['porcent_santander_daysthreshold']=df['market_volume_access'] * days
    
    df['non_concentrated_notional'] = df[['porcent_santander_daysthreshold', 'abs_notional']].min(axis=1)
    df['concentrated_notional']= df['abs_notional'] - df['non_concentrated_notional']
    
    # Encapsulamos estas lineas dentro de un control de warnings ya que sabemos que si no está informado el ISIN o la divisa, el código tirará un warning.
    # Estos ISIN ya se están mostrando en un output intermedio.
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")

        # Days until the concentrated notional is sold/bought. If an instrument matures prior to the expected time, the number of days is
        # capped to this number. On the other hand, no instrument which already matured should have an adjustment.
        if 'maturity' in df.columns:
            df.loc[:, 'days_until_maturity']=(df['maturity']-execution_date).dt.days.fillna(np.inf) # If we have empty dates, we assume that we may calculate the adjustment 
        else: #Si estamos usando inputs manuales asumimos que no vence antes de diez dias
            df.loc[:, 'days_until_maturity']=np.inf
        
        df.loc[:, 'required_days']= np.maximum(np.minimum(df['concentrated_notional'] / df['avg_daily_traded_volume'], df['days_until_maturity']), 0)
        
        # We do not need to include this in a dataframe column, as we can multiply value * numeric dataframe
        df['epsilon'] = np.sign(df['notional']) * epsilon
    
    df['prudent_price'] = df['AC_price'] * (1 + (2 / 3) * df['epsilon'] * param_y * df['vola'] * np.sqrt(df['required_days']))
    

    if all_same_currency:
	    # El ajuste en positivo, es decir, +100e de concentración quiere decir que el banco está 100e concentrado. -100e quiere decir que hay un descuento de 100e en la concentración (no contemplado)
        df['concentration_AVA'] = - df['epsilon'] * (df['AC_price'] - df['prudent_price']) * df['concentrated_notional'] / df['base input price']
        df.loc[:, 'concentration_AVA_native_currency'] = df.concentration_AVA * df.exchange_rate
    else:
        df['concentration_AVA_native_currency'] = -(df['AC_price'] - df['prudent_price']) * df['concentrated_notional'] / df['base input price']
        df.loc[:, 'concentration_AVA'] = df.concentration_AVA / df.exchange_rate
        
    # Aquellos que sean excepcion no tienen ajuste por concentración, y por tanto AVA = 0
    df.loc[df.exception, 'concentration_AVA'] = 0
    
    # Si ha vencido tiene ajuste cero
    df.loc[df.days_until_maturity.le(10), 'concentration_AVA']=0
    df.loc[df.days_until_maturity.le(10), 'concentration_AVA_native_currency']=0

    return df

def distribute_adjustment(df_adjustments, df_marginal_distribution):
    '''
    The following function calculates the adjustment distributed by ISIN-portfolio to be made to the passed possitions after a series of given parameters
    previously calculated, if any.
    
    Parameters
    ----------
        df_adjusmtments : Pandas dataframe 
            Dataframe containing the adjustments to include due to concentration
        df_marginal_distribution: Pandas dataframe
            Dataframe containing the notional correspoding to each portfolio for each ISIN
    
    Return
    ----------
        df : Pandas dataframe 
            Inputted with an additional column representing the adjustment distributed by ISIN-portfolio to include due to concentration.
    '''
    
    columns = ['ISIN', 'concentration_AVA']
    df_adj_f=df_adjustments.loc[:, columns].copy()
    
    df = df_marginal_distribution.merge(df_adj_f, how='left', on='ISIN')
    
    
    df['absolute_notional'] = df['Nominal Vivo'].abs()
    df['total_notional_ISIN'] = df.groupby(['ISIN'])['absolute_notional'].transform(sum)
    df['concentration_AVA_distributed'] = df['concentration_AVA'] * df['absolute_notional'] / df['total_notional_ISIN']
    df.drop(columns=['concentration_AVA', 'absolute_notional', 'total_notional_ISIN'], inplace = True)
   
    return df


if __name__ == '__main__':
#    master_path = r'C:\Users\cdasi\Documents\FVA AVA\03. Proyectos\04. Bonos y ABS\03. Concentracion\Codigo'
#
#    path_read = join(master_path, 'Input')
#
#    file_portfolio = r'cartera_bonos_ABS_20190930.xlsx'
#    print('Leyendo fichero de precio portoflio: %s' % file_portfolio)
#    df_portfolio = pd.read_excel(join(path_read, file_portfolio))
#    
#    df_portfolio.rename(columns = {'Sum of Nominal Vivo': 'Nocional', 'Nombre Corto Divisa (Divisa)': 'Divisa',
#                                   'LEVEL_1 (Portfolio)': 'Portfolio'}, inplace = True)
#    df_portfolio.loc[:, 'instrument'] = np.where(df_portfolio.Portfolio.apply(lambda x: 'abs' in x.lower()), 'ABS', 'Bond')
#    df_portfolio = pd.merge(df_portfolio, df_volatility, how='left', on='ISIN')
#    df_portfolio = pd.merge(df_portfolio, df_volume[['ISIN', 'avg_daily_traded_volume']], how='left', on='ISIN')
    
    df_portfolio_temp=pd.DataFrame({'avg_daily_traded_volume':[34783047.64, 63040537.31], 'ISIN':['ES0L02009113', 'BRSTNCLF1R25'], 'Nocional':[2502495000.00, 24510946.64],
                                    'AC_price': [100.333, 99.123], 'vola': [0.0001294833235548810, 0.00526706837323662]})
    df_AVA=ajuste_AVA(df=df_portfolio_temp)