"""
Created on Wed Jan 15 18:26:28 2020

@author: cdasi

Este codigo se ha desarrollado para la automatizacion del calculo del ajuste AVA por concentracion
"""

import pandas as pd
import numpy as np
from os.path import join
import warnings
import datetime

import fun_ajusteAVA as ava
import fun_groupby_proxy_v3 as gb_proxy
import fun_read_inputs as fri


# Definimos una serie de variables globales
epsilon = -1
param_y = 1

# Definimos un mapeo para los ratings, para elegir automáticamente el peor de la cartera en caso de no tener dato,
# y el diccionario inverso para revertir el rating codificado
ratings = ['AAA to A', 'AAA', 'AA', 'A', 'BBB to B', 'BBB', 'BB', 'B', 'CCC to D', 'CCC', 'CC', 'C', 'D']
rate_ratings = {rating: enum for enum, rating in enumerate(ratings)}
inv_rate_ratings = {v: k for k, v in rate_ratings.items()}

# Definimos el summary_report_log, que usaremos para hacer control del proceso
summary_report_log = {}


def print_output(dataframe, path_write, file_name, print_index=False):
    '''
    This is a support function where the given dataframe is written in the main variable "path_write".
    
    Parameters
    ----------
        dataframe : Pandas dataframe
            Dataframe to be exported to excel
        file_name : string 
            Name given with which the dataframe will be saved as
        print_index : Boolean, default False
            Wether to print or not the index column when exporting to excel
    
    Returns
    -------
        None
    '''
    
    try:
        summary_report_log['Printed outputs'] = summary_report_log['Printed outputs'] + ', ' + file_name
    except KeyError:
        summary_report_log['Printed outputs'] = file_name

    
    dataframe.to_excel(join(path_write, file_name), index=print_index)
    
    return None


def generate_price_bond(path_input_bonos, file_names, df_portfolio_bonos, df_volatility, df_volume, bond_volume_currency, tc, execution_date, path_out, print_out=True,
                        print_steps=True):
    '''
    This file generates the df_price_bonds dataframe, which contains the information regarding AC price, traded volume, and different
    other fields in order to generate the proxies for the bond portfolio
    
    Parameters
    ---------
        path_input_bonos : string
            Directory where the files used for the bond model are saved. The names of these files are hardcoded and should be named as such.
        df_portfolio_bonos : Pandas dataframe
            Containing the information regarding the portfolio, i.e., at least information about, 'ISIN', 'Divisa', 
            'Nocional', 'PRECIO AC', 'instrument', 'avg_daily_traded_volume'
        df_volatility : Pandas dataframe 
            Containing the historical volatility per ISIN
        execution_date : Datetime.datetime
            Portfolio date
        print_out : Boolean, default True
            Indicates if the output should be printed or not
        
    Returns
    -------
        df_price_bonds : Pandas dataframe
            Containing the information for filling fields of the portolio, in order to fill in missing data with the considered proxy
        bond_proxies : Pandas dataframe
            The output field values used for creating the different proxy axis values
    '''    
    bond_proxies=fri.read_file(path_input_bonos, file_names['bond_axis_data'])
    bond_proxies=bond_proxies.drop(columns=['region'])
    bond_proxies.rename(columns={'Area':'region', 'Currency':'currency','Industry':'COMB_IND', 'ticker':'ISIN', 'rating':'RATING_AC'}, inplace=True)
    
    # Sabemos que esto va a levantar un warning, por cómo lee Excel las fechas (día/mes/año hora:minuto:segundo:milisegundo:nanosegundo). Nosotros no tenemos
    # tanta precisión, así que sabemos que vamos a perder la precisión hasta el día, y el warning por tanto no nos importa
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")

        # Filtramos las fechas mayores al máximo que puede almacenar pandas y eliminamos aquellas que anteriores a fecha de ejecución
        bond_proxies.loc[bond_proxies.maturity > pd.Timestamp.max, 'maturity'] = pd.Timestamp.max
        bond_proxies = bond_proxies.loc[(bond_proxies.maturity >= execution_date) | (bond_proxies.maturity.isna()), :].copy()
        # bond_proxies = bond_proxies.loc[bond_proxies.maturity >= execution_date, :].copy()

    # Generamos el maturity_tranche, primero pasamos la diferencia entre maturity y ejecucion a dias (contando bisiestos) y luego a años.    
    
    bond_proxies.loc[:, 'year'] = bond_proxies.maturity - execution_date
    bond_proxies['year'] = bond_proxies['year'] / np.timedelta64(1,'Y')
        
    bond_proxies['maturity_tranche'] = np.where(bond_proxies.year > 7, 't > 7Y', np.where(bond_proxies.year >= 3, '3Y <= t <= 7Y', np.where(bond_proxies.year < 3, 't < 3Y', np.nan)))     # Usamos 2555 dias son 7 años, 1095 son 3
    bond_proxies['maturity_tranche'] = np.where(bond_proxies.maturity_tranche.eq('nan'), np.nan, bond_proxies.maturity_tranche)
    
    # Esta opcion no tenia en cuenta bisiestos   
    # bond_proxies['maturity_tranche'] = np.where(bond_proxies.day > datetime.timedelta(days=2555), 't > 7Y', np.where(bond_proxies.day >= datetime.timedelta(days=1095), '3Y <= t <= 7Y', np.where(bond_proxies.day < datetime.timedelta(days=1095), 't < 3Y', np.nan)))     # Usamos 2555 dias son 7 años, 1095 son 3
    # bond_proxies['maturity_tranche'] = np.where(bond_proxies.maturity_tranche.eq('nan'), np.nan, bond_proxies.maturity_tranche)
    
    if print_steps:
        print('>>    Including the average traded volume and volatility to the proxy instruments')
    bond_proxies=bond_proxies.merge(df_volume, on='ISIN', how='left')

    # Aplicamos el tipo de cambio a los volúmenes
    if bond_volume_currency=='native':
        bond_proxies.loc[:, 'avg_daily_traded_volume'] = (bond_proxies.avg_daily_traded_volume / bond_proxies.currency.map(tc)).values
    else:
        bond_proxies.loc[:, 'avg_daily_traded_volume'] = (bond_proxies.avg_daily_traded_volume / tc[bond_volume_currency]).values
    
    # Voy a eliminar duplicados y nan de la volatilidad porque sino se duplican los ISIN en los merge
    df_volatility=df_volatility.dropna(subset=['vola'])
    df_volatility=df_volatility.drop_duplicates()
    bond_proxies=bond_proxies.merge(df_volatility, on='ISIN', how='left')
    
    # Añadimos al dataframe la volatilidad, la variable que nos indica el bucket "temporal" y renombramos columnas por comodidad
    df_price_bonds = df_portfolio_bonos.merge(df_volatility, on=['ISIN'], how='left')
    df_price_bonds.rename(columns={'Nombre Corto Divisa (Divisa)': 'currency', 
                                   'Sum of Nominal Vivo': 'notional'}, inplace=True)
    
    # Incluimos en el dataframe global las 3 columnas que nos faltan para el proxy
    # df_price_bonds = pd.merge(df_price_bonds, bond_proxies[['ISIN', 'COMB_IND', 'COMB_REG',  'RATING_AC', 'maturity_tranche', 'country']], on='ISIN', how='left')
    df_price_bonds = df_price_bonds.merge(bond_proxies[['ISIN', 'COMB_IND', 'RATING_AC', 'maturity', 'maturity_tranche']], on='ISIN', how='left') 
    # De nuevo elimino duplicados, por que en el merge anterior los que están en varias mesas se estan duplicando
    df_price_bonds=df_price_bonds.drop_duplicates()

    # Contamos la cantidad de entradas sin rating    
    summary_report_log['df_price_bonds filas sin rating'] = df_price_bonds.RATING_AC.isnull().sum()

    # Rellenamos los ratings que faltan con los peores que hay en cartera
    # non_null_rating = df_price_bonds.loc[~df_price_bonds['AC_price'].isnull(), 'RATING_AC'].map(rate_ratings).max()
    # worst_rating = inv_rate_ratings[non_null_rating]
    # worst_rating=fri.read_file(path_input_bonos, file_names['bonds fallback'])
    # worst_rating=worst_rating.values[0][0]
    # df_price_bonds.RATING_AC.fillna(worst_rating, inplace=True)

    if print_out:
        print_output(dataframe=bond_proxies, path_write=path_out, file_name='bond_proxies.xlsx')
        
    summary_report_log['bond_proxies filas'] = bond_proxies.shape[0]

    return df_price_bonds, bond_proxies


def aplica_proxies(df, df_proxy, fields_map, path_input, file_names, instrument, minimum_observations=3, max_iter=10, print_steps=True):
    '''
    With this function we map the null and zero values from a given set of fields to the values found in a different dataframe.
    
    Parameters
    ----------
        df : Pandas dataframe
            Dataframe with the null or zero values to be mapped.
        df_proxy : Pandas dataframe
            Dataframe with the values which will be used to map the null or zero values in the dataframe df
        fields_map : Dictionary
            Dictionary with keys the fields in df to be mapped and items the fields in df_proxy to use
        minimum_observations : Integer, default 3
            Minimum number of observations to consider. I.e., when calculating a group, by at least minimum_observations
            observations must be used for generating the values.
        max_iter : Integer, default 10.
            Maximum number of iterations to calculate for when applying the proxies and performing fallbacks. Ideally should be
            the number of consdiered levels in the hierarchical proxy.
        
    Returns
    -------
        df : Pandas dataframe
            The inputted dataframe with the mapped fields as well as a series of additional fields
    '''
    
    # Para los elementos que hay en df_proxies con menos de minimum_observations observaciones, vamos a setearlos como 
    # cero, ya que estos se eliminarán más adelante y se aplicará un fallback.
    for column in fields_map.values():
        dict_map={ix: 0 for ix in range(1, minimum_observations)}
        df_proxy.loc[:, column] = df_proxy[column+'_count'].map(dict_map).fillna(df_proxy[column])
    df_proxy = df_proxy[df_proxy.avg_daily_traded_volume_P50 != 0]  
    df_proxy = df_proxy[df_proxy.vola_P50 != 0]
    df.loc[:,'proxy_aplicado'] = ''
    
    fields = []
    for field in fields_map.keys():
        fields.append(field)
        field_map=fields_map[field]
        
        dict_map = {key_:volume_ for key_, volume_ in zip(df_proxy['key'], df_proxy[field_map])}
        cond_field=(df[field].isnull() | df[field].eq(0))
        
        
        # df.loc[cond_field , 'proxy_aplicado'] = df.proxy_aplicado + ' + ' + field
        df.loc[cond_field , 'proxy_aplicado'] = 'TRUE' 
        
        df.loc[cond_field , field] = df.loc[cond_field , 'key'].map(dict_map)
    # df['proxy_aplicado']=df['proxy_aplicado'].str[3:]
    # Aquellos que tienen volumen cero tras esto, es porque tienen bucket pero el bucket tiene como cero el avg_daily_traded_volume o la vola.
    # Aquí tiramos un fallback y recalculamos hasta que deje de ser cero
    df.loc[:,'proxy_aplicado']=np.where(df.proxy_aplicado.eq('TRUE'), df.proxy_aplicado, 'FALSE')
    
    if print_steps:
            print('>>    Applying proxies to the required instruments')
    for field_to_complete in fields:
        master_condition = ((df[field_to_complete].isnull() | df[field_to_complete].eq(0)) & df['key'].notna())
        
    # Generamos un campo adicional para mantener la key original, y ver los que han sido modificados cuanto han tenido que 
    # desplazarse
        df.loc[:, 'modified_key']=''
        df.loc[master_condition, 'modified_key'] = df.loc[master_condition, 'key']
    
        iteracion=0
        while df.loc[master_condition, 'key'].count()>0:
        # if print_steps:
        #     print('>    Tenemos %i filas no validas' % df.loc[master_condition, 'modified_key'].count())
           new_key = df.loc[master_condition, 'modified_key'].apply(lambda x: '-'.join(x.split('-')[:-1]))
           df.loc[master_condition, 'modified_key'] = new_key
    
           field_map=fields_map[field_to_complete]
           dict_map = {key_:volume_ for key_, volume_ in zip(df_proxy['key'], df_proxy[field_map])}
           df.loc[master_condition, field_to_complete] = df.loc[master_condition , 'modified_key'].map(dict_map)
    
           master_condition = (df[field_to_complete].isnull() | df[field_to_complete].eq(0))
        
           if iteracion > max_iter:		   
              if print_steps:
                  print('>>       * Se han superado el numero maximo de iteraciones, parece que necesitaras mas datos para poder realizar el proxy' +
                      ' adecuadamente, o tendras que reducir el numero de observaciones minimas. ' + 
                      'Aun quedan %i ISIN con algun dato NaN o cero. *' % df.loc[master_condition, 'modified_key'].count())
              break
           iteracion+=1																									

        # En caso de que tras la iteración anterior no hayamos podido completar alguno de los buckets, aplicamos el valor del proxy 
        # mas punitivo (CCC to D)
        # Determinamos el más punitivo
        key_punitiva=df_proxy.loc[df_proxy[field_map].eq(df_proxy[field_map].min()), 'key'].values[0]
        user_rating=fri.read_file(path_input, file_names[instrument])
        user_rating=user_rating.values[0][0]
        df['modified_key']=np.where(df[field_to_complete].isnull(), 'User parametrization', df['modified_key'])
        df[field_to_complete]=np.where(df[field_to_complete].isnull(), dict_map[user_rating], df[field_to_complete])
        # Arriba rellenamos con la parametrizacion del usuario, en caso de no tener dato aplicamos el dato mas punitivo
        df['modified_key']=np.where(df[field_to_complete].isnull(), 'Most punitive key', df['modified_key'])
        df[field_to_complete]=np.where(df[field_to_complete].isnull(), dict_map[key_punitiva], df[field_to_complete])
    # for field_to_complete in fields: 
    #     if df[field_to_complete].isna().any():
    #         field_map=fields_map[field_to_complete]
    #         dict_map = {key_:volume_ for key_, volume_ in zip(df_proxy['key'], df_proxy[field_map])}
    #         df[field_to_complete]=np.where(df[field_to_complete].isnull(), dict_map['CCC to D'], df[field_to_complete])
    return df

def aplica_proxies_issuer(df, df_proxy, apply_issuer_proxy):
    '''
    With this function we map the null and zero values from a given set of fields to the values found in a different dataframe.    
    
    Parameters
    ----------
        df : Pandas dataframe
            Dataframe with the null or zero values to be mapped.
        df_proxy : Pandas dataframe
            Dataframe with the values which will be used to map the null or zero values in the dataframe df
        
    Returns
    -------
        df : Pandas dataframe
            The inputted dataframe with the mapped fields as well as a series of additional fields
    '''
    if df_proxy.Issuer.isna().all():
       df['issuer_proxy_aplicado']='No issuer available for volume'
       return df
    else:
       average_issuer_volume = df_proxy.groupby(['Issuer'])['avg_daily_traded_volume'].quantile(q=0.5)
       average_issuer_volume = average_issuer_volume.to_frame()
       average_issuer_volume = average_issuer_volume.rename(columns={'avg_daily_traded_volume': 'avg_issuer_daily_traded_volume'})
    
       df_proxy = df_proxy.merge(average_issuer_volume, on='Issuer', how ='left')
       df_proxy = df_proxy.rename(columns={'Issuer':'issuer'})
       df_proxy = df_proxy.loc[:, ['issuer','avg_issuer_daily_traded_volume']]
       df_proxy.drop_duplicates(inplace=True)
   
       df.loc[:, 'issuer_proxy_aplicado'] = np.where((df.avg_daily_traded_volume.isna()) & (df.issuer.isin(df_proxy.issuer)), True, False)
       df = df.merge(df_proxy, on= 'issuer', how = 'left')
       df.loc[:,'avg_daily_traded_volume'] = np.where(df.avg_daily_traded_volume.isna(), df.avg_issuer_daily_traded_volume, df.avg_daily_traded_volume)
       df=df.drop(columns=['issuer', 'avg_issuer_daily_traded_volume']) 
    
       return df


def generate_price_abs(path_input_ABS, files, df_portfolio_ABS, df_volatility, df_volume, abs_volume_currency, tc, execution_date, print_out, 
                       path_out, print_steps=True):
    '''
    This file generates the df_price_bonds dataframe, which contains the information regarding AC price, traded volume, and different
    other fields in order to generate the proxies for the bond portfolio
    
    Parameters
    ---------
        path_input_bonos : string
            Directory where the files used for the bond model are saved. The names of these files are hardcoded and should be named as such.
        df_portfolio_bonos : Pandas dataframe
            Containing the information regarding the portfolio, i.e., at least information about  'ISIN', 'Divisa', 
            'Nocional', 'AC_price', 'instrument', 'avg_daily_traded_volume'
        df_volatility : Pandas dataframe 
            Containing the historical volatility per ISIN
        execution_date : Datetime.datetime
            Portfolio date
        print_out : Boolean, default True
            Indicates if the output should be printed or not
        
    Returns
    -------
        df_price_bonds : Pandas dataframe
            Containing the information for filling fields of the portolio, in order to fill in missing data with the considered proxy
        bond_proxies : Pandas dataframe
            The output field values used for creating the different proxy axis values
    '''
    
    print('>>    Reading static data files')
    print('*    %s' % files['abs_axis_data'])
    abs_proxies=fri.read_file(path_input_ABS, files['abs_axis_data'])
    abs_proxies.rename(columns={'rating': 'RATING_AC'}, inplace=True)
    
    # De los ratings disponibles en la cartera (teóricamente todos, pero es un control por solidez del código), tomamos el peor para rellenar los
    # proxies sin rating
    df_portfolio=abs_proxies.loc[abs_proxies.ISIN.isin(df_portfolio_ABS.ISIN), :]
    # if df_portfolio.RATING_AC.isnull().all():
    #     worst_rating='CCC to D'
    # else:
    #     worst_rating = inv_rate_ratings[df_portfolio.loc[~df_portfolio['RATING_AC'].isnull(), 'RATING_AC'].map(rate_ratings).max()]
    # worst_rating=fri.read_file(path_input_ABS, files['abs fallback'])
    # worst_rating=worst_rating.values[0][0]
    # abs_proxies.RATING_AC.fillna(worst_rating, inplace=True)
    
    if print_steps:
        print('>>    Including the average traded volume and volatility to the proxy instruments')
    abs_proxies=abs_proxies.merge(df_volume, on='ISIN', how='left')
    # Aplicamos el tipo de cambio a los volúmenes
    if abs_volume_currency=='native':
        abs_proxies.loc[:, 'avg_daily_traded_volume'] = abs_proxies.loc[:, 'avg_daily_traded_volume'] / abs_proxies.loc[:, 'currency'].map(tc)
    else:
        abs_proxies.loc[:, 'avg_daily_traded_volume'] = abs_proxies.loc[:, 'avg_daily_traded_volume'] / tc[abs_volume_currency]

    abs_proxies=abs_proxies.merge(df_volatility, on='ISIN', how='left')

    # Añadimos al dataframe la volatilidad, la variable que nos indica el bucket "temporal" y renombramos columnas por comodidad
    df_price_abs = df_portfolio_ABS.merge(df_volatility, on=['ISIN'], how='left')
    df_price_abs.rename(columns={'Nombre Corto Divisa (Divisa)': 'currency', 
                                 'Sum of Nominal Vivo': 'notional'}, inplace=True)    
    
    df_price_abs = pd.merge(df_price_abs, abs_proxies[['ISIN', 'RATING_AC', 'instrument_type', 'industry', 'maturity']], on='ISIN', how='left')
	
    summary_report_log['df_price_abs filas sin rating'] = df_price_abs.RATING_AC.isnull().sum()

    # Rellenamos los ratings que faltan con los peores que hay en cartera
    # non_null_rating = df_price_abs.loc[~df_price_abs['AC_price'].isnull(), 'RATING_AC'].map(rate_ratings).max()
    # worst_rating = inv_rate_ratings[non_null_rating]
    # df_price_abs.RATING_AC.fillna(worst_rating, inplace=True)
    
    df_price_abs.loc[:, 'RATING_AC_original'] = df_price_abs.loc[:, 'RATING_AC']
    abs_proxies.loc[:, 'RATING_AC_original'] = abs_proxies.loc[:, 'RATING_AC']
    
    # df_price_abs.loc[df_price_abs.RATING_AC.eq('SIN_CALIFI'), 'RATING_AC'] = worst_rating
    # abs_proxies.loc[abs_proxies.RATING_AC.eq('SIN_CALIFI'), 'RATING_AC'] = worst_rating
    
    # Generamos los buckets del proxy para aquellos ISIN con información para evitar errores de código
    df_price_abs_empty=df_price_abs[df_price_abs.RATING_AC_original.isna()]
    df_price_abs=df_price_abs[df_price_abs.RATING_AC_original.notna()]
    abs_proxies_empty=abs_proxies[abs_proxies.RATING_AC_original.isna()]
    abs_proxies=abs_proxies[abs_proxies.RATING_AC_original.notna()]
    
    df_price_abs.loc[:, 'RATING_AC']=np.where(df_price_abs.RATING_AC.apply(lambda x: 'A' in x), 'AAA to A', 
                                              np.where(df_price_abs.RATING_AC.apply(lambda x: 'B' in x), 'BBB to B', 
                                                       'CCC to D'))
    abs_proxies.loc[:, 'RATING_AC']=np.where(abs_proxies.RATING_AC.apply(lambda x: 'A' in x), 'AAA to A', 
                                              np.where(abs_proxies.RATING_AC.apply(lambda x: 'B' in x), 'BBB to B', 
                                                       'CCC to D'))
    
    # Volvemos a juntar los dfs
    df_price_abs=pd.concat([df_price_abs, df_price_abs_empty])
    abs_proxies=pd.concat([abs_proxies, abs_proxies_empty])
    
    if print_out:
        print_output(dataframe=abs_proxies, path_write=path_out, file_name='abs_proxies.xlsx')
        
    summary_report_log['abs_proxies filas'] = abs_proxies.shape[0]
    
    return df_price_abs, abs_proxies


def do(master_path, tool_parameters):
    '''
    Main function
    '''
    
    # Convertimos el tool_parameters a un diccionario
    tool_parameters=fri.read_file(master_path, tool_parameters)
    dict_files={row['Field']: row['Value'] for _, row in tool_parameters[['Field', 'Value']].iterrows()}
    
    path_read = dict_files['path read']
    path_write = dict_files['path write']
    
    print_out=dict_files['print out']
    print_steps=dict_files['print steps']
    apply_issuer_proxy=dict_files['issuer proxy']
    abs_included=dict_files['ABS included']
    
    execution_date=dict_files['execution date']
    
    base_currency=dict_files['reporting currency']
    base_input_price=dict_files['base input price']

    # Generamos la variable con el tipo de cambio
    df_tc = fri.read_file(path_read, dict_files['exchange rate file'])
    tc = {curr: exch_rate for curr, exch_rate in zip(df_tc['currency'], df_tc['exchange_rate'])}
    tc_aux = tc.copy()
    del(tc_aux[base_currency])
    
    if tc[base_currency] != 1:
        raise Warning(f"Exchange rate file may be wrong: Base currency fx rate {base_currency} not set to 1.")
    elif 1 in tc_aux.values():
        print("Caution! The exchange rate file may be wrong, there are multiple exchange rates set to 1.")
    
    print('------- INPUT FEEDING -------')
    
    if abs_included:
        volume_files = {'bonds': dict_files['bond volume file'], 'abs': dict_files['ABS volume file']}
    else:
        volume_files = {'bonds': dict_files['bond volume file']}
        
    df_volume = fri.read_volume(path_read_main=path_read, volume_files=volume_files, abs_included=abs_included, print_steps=print_steps)
    
    if abs_included:
        vola_files = {'bonds': dict_files['bond volatility file'], 'abs': dict_files['ABS volatility file']}
    else:
        vola_files = {'bonds': dict_files['bond volatility file']}

    df_volatility=fri.load_volatility(path_read, vola_files, abs_included, print_steps)
    
    # summary_report_log['Volatility calculation'] = 'Custom (user defined and hardcoded)' if custom else str(volatility_timewindow) + ' timewindow' + (' with only end of month observations' if end_of_month_vola else '')
    summary_report_log['Volatility files'] = ', '.join([':'.join([key, item]) for key, item in zip(vola_files.keys(), vola_files.values())])
    
    if abs_included:
        files={'portfolio abs': dict_files['ABS model output'], 
            'portfolio bond': dict_files['Bond model output'], 
            'bond_axis_data': dict_files['bond static data'], 
            'excepciones': dict_files['exemption file'],
            'porcentajes': dict_files['market access percentajes'],
            'exclusiones': dict_files['exclusions file']}
    else:
        files={'portfolio bond': dict_files['Bond model output'], 
           'bond_axis_data': dict_files['bond static data'], 
           'excepciones': dict_files['exemption file'],
           'porcentajes': dict_files['market access percentajes'],
           'exclusiones': dict_files['exclusions file']}
        
    summary_report_log['read_portfolio files'] = ', '.join([':'.join([key, item]) for key, item in zip(files.keys(), files.values())])
    if abs_included:
        df_portfolio_bonds, df_portfolio_ABS = fri.read_portfolio(path_read=path_read, df_volume=df_volume, tc=tc, base_currency=base_currency, base_input_price = base_input_price, files=files,
                                                                  bond_volume_currency=dict_files['bond volume currency'], abs_volume_currency=dict_files['ABS volume currency'],
                                                                  default_market_percentaje=None, abs_included=abs_included, print_steps=print_steps, path_write=path_write)
          
    else:
        df_portfolio_bonds=fri.read_portfolio(path_read=path_read, df_volume=df_volume, tc=tc, base_currency=base_currency, base_input_price = base_input_price, files=files,
                                              bond_volume_currency=dict_files['bond volume currency'], abs_volume_currency=dict_files['ABS volume currency'],
                                              default_market_percentaje=None, abs_included=abs_included, print_steps=print_steps, path_write=path_write)
        
    # En caso de que no haya ningun bono cabe la posibilidad de que el usuario quiera hacer una ejecución introduciendo solo instrumentos
    # de forma manual. Permitimos que esto suceda. 
    if df_portfolio_bonds.empty:
        
        df_price_bonds=pd.DataFrame()
        only_inputs=True
        
    else:
        
        only_inputs=False
        bonds_issuers = df_portfolio_bonds.copy()
        bonds_issuers = bonds_issuers.drop_duplicates()
        if apply_issuer_proxy:
            df_portfolio_bonds = aplica_proxies_issuer(df_portfolio_bonds, df_volume, apply_issuer_proxy)
        else:
            df_portfolio_bonds['issuer_proxy_aplicado'] = 'No'
    
        print('\n------- BOND EXECUTION -------')
    
        # Execution for bonds
        if print_steps:
            print('>  Generating bond proxy file')
        file_names={'bond_axis_data': dict_files['bond static data'],
                    'bonds fallback': dict_files['Bonds proxy fallback']}
        summary_report_log['generate_price_bond files'] = ', '.join([':'.join([key, item]) for key, item in zip(file_names.keys(), file_names.values())])
    
        df_price_bonds, bond_proxies = generate_price_bond(path_read, file_names=file_names, df_portfolio_bonos=df_portfolio_bonds, bond_volume_currency=dict_files['bond volume currency'],
                                                           df_volatility=df_volatility, df_volume=df_volume, execution_date=execution_date, tc=tc,
                                                           path_out=path_write, print_out=print_out)
    
        if print_out:
            print_output(dataframe=df_price_bonds, path_write=path_write, file_name='df_price_bonds.xlsx')
                
        if print_steps:
            print('>  Generating proxy bucket values')
        bucket_keys_bonds = ['RATING_AC', 'maturity_tranche', 'COMB_IND', 'region']
        summary_report_log['group_by_proxy bucket keys for bonds'] = ', '.join(bucket_keys_bonds)
    
        group_by_values_bonds = ['avg_daily_traded_volume','vola']
        summary_report_log['group_by_proxy group by variables for bonds'] = ', '.join(group_by_values_bonds)
    
        percentile_level=0.50
        summary_report_log['group_by_proxy group by calculation for bonds'] = 'Percentile ' + str(percentile_level) if percentile_level else 'Average'
    
        omit_nans=True
        omit_zeros=True
        summary_report_log['group_by_proxy additional parameters for bonds'] = 'Null values and zeros ommited for the calculation' if (omit_nans and omit_zeros) else (
                'Null values for the calculation' if omit_nans else ('Zeros ommited for the calculation' if omit_zeros else 'Null values and zeros considered for the calculation'))
    
        df_proxy_gb_bonds = gb_proxy.group_by_proxy(df=df_price_bonds, df_proxy=bond_proxies, bucket_list=bucket_keys_bonds, 
                                                    group_by_values=group_by_values_bonds,
                                                    percentile_level=percentile_level, omit_nans=omit_nans, 
                                                    omit_zeros=omit_zeros)
        
        if print_out:
            print_output(dataframe=df_proxy_gb_bonds, path_write=path_write, file_name='df_proxy_gb_bonds.xlsx')
            # print_output(dataframe=df_proxy_gb_bonds_vola, path_write=path_write, file_name='df_proxy_gb_bonds_vola.xlsx')
            summary_report_log['group_by_proxy generated buckets for bonds'] = df_proxy_gb_bonds.shape[0]
            # summary_report_log['group_by_proxy vola generated buckets for bonds'] = df_proxy_gb_bonds_vola.shape[0]
        
        if print_steps:
            print('>>    Mapping missing values per proxy')
        
        minimum_observations=3
        max_iter=5
        # Marcamos el mínimo para que se aplique un proxy en bonos
       
        if type(percentile_level)==float or type(percentile_level)==int:
            fields_map = {'avg_daily_traded_volume': 'avg_daily_traded_volume_P'+str(int(percentile_level*100))}
        elif percentile_level is None:
            fields_map = {'avg_daily_traded_volume': 'avg_daily_traded_volume_mean'}
        summary_report_log['Observaciones minimas para aplicar proxy en bonos'] = minimum_observations
        summary_report_log['Columnas proxeadas en bonos'] = ', '.join([':'.join([key, item]) for key, item in zip(fields_map.keys(), fields_map.values())])
        df_price_bonds_volume = aplica_proxies(df=df_price_bonds, df_proxy=df_proxy_gb_bonds, fields_map=fields_map, path_input=path_read, file_names=file_names, instrument='bonds fallback',
                                        minimum_observations=minimum_observations)
        df_price_bonds_volume=df_price_bonds_volume.copy()
        
        if type(percentile_level)==float or type(percentile_level)==int:
            fields_map = {'vola': 'vola_P'+str(int(percentile_level*100))}
        elif percentile_level is None:
            fields_map = {'vola': 'vola_mean'}
        summary_report_log['Observaciones minimas para aplicar proxy en bonos'] = minimum_observations
        summary_report_log['Columnas proxeadas en bonos'] = ', '.join([':'.join([key, item]) for key, item in zip(fields_map.keys(), fields_map.values())])
        df_price_bonds_vola = aplica_proxies(df=df_price_bonds, df_proxy=df_proxy_gb_bonds, fields_map=fields_map, path_input=path_read, file_names=file_names, instrument='bonds fallback',
                                        minimum_observations=minimum_observations)
        
        df_price_bonds=df_price_bonds_volume.merge(df_price_bonds_vola, on=[ 'ISIN', 'currency', 'notional', 'Industry', 
                                                                            'AC_price', 'exchange_rate', 'exception', 'market_percentaje_santander', 
                                                                            'COMB_IND', 'RATING_AC', 'maturity', 'maturity_tranche', 'Bucket', 'region'])
        
      
        df_price_bonds=df_price_bonds.rename(columns={'issuer_x':'issuer','base_currency_x':'base_currency','key_x':'key_volume', 'proxy_aplicado_x':'proxy_aplicado_volume', 
                                                      'modified_key_x':'modified_key_volume', 'key_y':'key_vola', 'proxy_aplicado_y':'proxy_aplicado_vola', 
                                                      'modified_key_y':'modified_key_vola', 'vola_y':'vola', 'avg_daily_traded_volume_x':'avg_daily_traded_volume', 
                                                      'issuer_proxy_aplicado_x':'issuer_proxy_aplicado', 'base input price_x':'base input price'})
    

        
        bonds_issuers = bonds_issuers[['ISIN', 'issuer']].rename(columns={'issuer':'issuer_new'})
        df_price_bonds = df_price_bonds.merge(bonds_issuers, on=['ISIN'], how='left')
        df_price_bonds.loc[:, 'issuer'] = np.where(df_price_bonds.issuer.isna(), df_price_bonds.issuer_new, df_price_bonds.issuer)
        df_price_bonds.drop(columns=['issuer_new'], inplace=True)
        
        #df_price_bonds.loc[:, 'issuer'] = np.where(df_price_bonds.issuer.isna(), bonds_issuers.issuer, df_price_bonds.issuer)

        
    # Ahora modificamos manualmente los datos del average daily traded volume que han sido inputados por ISIN en el fichero.																												
    if print_steps:
        print('>    Including (if any) the user defined input volumes for the bond portfolio')
    files_modificacion={'manual changes': dict_files['bonds user inputted changes']}
    df_price_bonds, df_manual_bonds = fri.aplica_inputs_manuales(path_read=path_read, files_modificacion=files_modificacion, df=df_price_bonds, product='bonds', path_write=path_write, 
                                                tc=tc, base_currency=base_currency)
    
    
    if print_steps:
        print('>  Calculating bond concentration AVA') 
    
    days_threshold=10
    all_same_currency=True

    df_bonds_AVA = ava.ajuste_AVA(exchange_rates=tc, df=df_price_bonds, param_y=param_y, epsilon=epsilon, days=days_threshold, 
                                  all_same_currency=all_same_currency, execution_date=execution_date)
    
    
    # # Renombramos la columna de nominal, para aclarar que el output se presenta en €
    # df_bonds_AVA=df_bonds_AVA.rename(columns={"notional": f"notional_{base_currency}"})osea 
    
    # Solo vamos a mostrar en "avg_daily_traded_volumen" aquellos datos que no han sido proxeados, el resto están en market_volumen_access
    # Separamos aquellos ISIN donde no tenemos divisa o dato de AC. En caso de que no haya número de ISIN también es separado. 
    df_bond_AVA_warning=df_bonds_AVA[df_bonds_AVA['currency'].isnull() | df_bonds_AVA['AC_price'].isnull() | df_bonds_AVA['ISIN'].isnull()]
    
    if len(df_bond_AVA_warning)>1:
        print(f'-·-> ATTENTION: There are {len(df_bond_AVA_warning)} underlyings without ISIN, currency or AC price')
        df_bond_AVA_warning=df_bond_AVA_warning[['ISIN', 'currency', 'AC_price']]
        print_output(dataframe=df_bond_AVA_warning, path_write=path_write, file_name='Bonds_missing_values.xlsx')  
    elif len(df_bond_AVA_warning)==1:
        print(f'-·-> ATTENTION: There is {len(df_bond_AVA_warning)} underlying without ISIN, currency or AC price')
        df_bond_AVA_warning=df_bond_AVA_warning[['ISIN', 'currency', 'AC_price']]
        print_output(dataframe=df_bond_AVA_warning, path_write=path_write, file_name='Bonds_missing_values.xlsx')  
    else:
        df_bond_AVA_warning=df_bond_AVA_warning[['ISIN', 'currency', 'AC_price']]
        print_output(dataframe=df_bond_AVA_warning, path_write=path_write, file_name='Bonds_missing_values.xlsx')  
        
#    df_bonds_AVA=df_bonds_AVA[df_bonds_AVA['currency'].notnull() & df_bonds_AVA['AC_price'].notnull() & df_bonds_AVA['ISIN'].notnull()]

    if print_steps:
        print(f'\n-·-> Concentration AVA for bond portfolio: {df_bonds_AVA.concentration_AVA.sum():,.2f}')
    summary_report_log['Ajuste AVA por concentracion en bonos'] = df_bonds_AVA.concentration_AVA.sum()
    
    #Si solo hemos metido inputs manuales paramos el proceso y generamos el reporte 
    if only_inputs:
        
        print_output(dataframe=df_bonds_AVA, path_write=path_write, file_name='df_bonds_AVA.xlsx')
        
        return df_bonds_AVA, summary_report_log
    
    if print_out:
        if print_steps:
            print('\nSalvando el output generado')
        df_bonds_AVA.drop(columns=['exchange_rate', 'currency', 'concentration_AVA_native_currency'], inplace=True)
        df_bonds_AVA_resumen = df_bonds_AVA[['ISIN', 'notional', 'AC_price', 'avg_daily_traded_volume', 'exception', 'market_percentaje_santander',
                                             'base_currency', 'vola', 'porcent_santander_daysthreshold', 'non_concentrated_notional', 'concentrated_notional',
                                             'prudent_price', 'concentration_AVA']].copy()
        df_bonds_AVA = df_bonds_AVA[['index','ISIN', 'issuer', 'notional', 'region','Industry', 'AC_price', 'avg_daily_traded_volume', 'exception', 'market_percentaje_santander', 'base_currency', 'issuer_proxy_aplicado', 'COMB_IND', 'RATING_AC', 'maturity', 'maturity_tranche', 'Bucket', 'key_volume', 'proxy_aplicado_volume', 'modified_key_volume',	'vola', 'key_vola',	'proxy_aplicado_vola',	'modified_key_vola', 'market_volume_access','abs_notional',	'porcent_santander_daysthreshold', 'non_concentrated_notional', 'concentrated_notional', 'days_until_maturity', 'required_days', 'epsilon',	'prudent_price', 'concentration_AVA']]
        print_output(dataframe=df_bonds_AVA, path_write=path_write, file_name='df_bonds_AVA.xlsx')
        print_output(dataframe=df_bonds_AVA_resumen, path_write=path_write, file_name='df_bonds_AVA_summary.xlsx')    
    
    df_marginal_distribution = fri.read_file(path_read, dict_files['marginal distribution bonds'])    
    df_marginal_distribution.rename(columns = {'ticker': 'ISIN'}, inplace=True)
    df_marginal_distribution.drop(columns=['Currency', 'FVA CoC dist', 'FVA MPU dist'], inplace = True)
    
    
    keep_columns = ['ISIN', df_marginal_distribution.columns[1], 'notional']
    df_manual_bonds = df_manual_bonds.loc[:, keep_columns]
    df_manual_bonds.rename(columns={'notional': 'Nominal Vivo'}, inplace = True)
    df_marginal_distribution = df_marginal_distribution.append(df_manual_bonds)
    df_bonds_AVA_distributed = ava.distribute_adjustment(df_bonds_AVA, df_marginal_distribution)

    print_output(dataframe=df_bonds_AVA_distributed, path_write=path_write, file_name='df_bonds_AVA_distributed.xlsx')
    
    
    # Execution for ABS
    if abs_included:
        print('\n------- ABS EXECUTION -------')
        if print_steps:
            print('>  Generating ABS proxy file')
        files = {'abs_axis_data': dict_files['ABS static data'],
                 'abs fallback': dict_files['ABS proxy fallback']}
        summary_report_log['generate_price_abs files'] = ', '.join([':'.join([key, item]) for key, item in zip(files.keys(), files.values())])

        df_price_abs, abs_proxies = generate_price_abs(path_input_ABS=path_read, files=files, df_portfolio_ABS=df_portfolio_ABS, abs_volume_currency=dict_files['ABS volume currency'],
                                                       df_volatility=df_volatility, df_volume=df_volume, execution_date=execution_date, tc=tc,
                                                       print_out=print_out, path_out=path_write)
        if print_out:
            print_output(dataframe=df_price_abs, path_write=path_write, file_name='df_price_abs.xlsx')
    
        if print_steps:
            print('>  Generating proxy bucket values')
        bucket_keys_abs = ['RATING_AC', 'instrument_type']
        summary_report_log['group_by_proxy bucket keys for ABS'] = ', '.join(bucket_keys_abs)
        
        group_by_values_abs = ['avg_daily_traded_volume','vola']
        summary_report_log['group_by_proxy group by variables for ABS'] = ', '.join(group_by_values_abs)

        percentile_level=0.5
        summary_report_log['group_by_proxy group by calculation for ABS'] = 'Percentile ' + str(percentile_level) if percentile_level else 'Average'

        omit_nans=True
        omit_zeros=True
        summary_report_log['group_by_proxy additional parameters for ABS'] = 'Null values and zeros ommited for the calculation' if (omit_nans and omit_zeros) else (
                'Null values for the calculation' if omit_nans else ('Zeros ommited for the calculation' if omit_zeros else 'Null values and zeros considered for the calculation'))

        df_proxy_gb_abs = gb_proxy.group_by_proxy(df=df_price_abs, df_proxy=abs_proxies, bucket_list=bucket_keys_abs, group_by_values=group_by_values_abs, 
                                              percentile_level=percentile_level, omit_nans=omit_nans, omit_zeros=omit_zeros)
    
        if print_out:
            print_output(dataframe=df_proxy_gb_abs, path_write=path_write, file_name='df_proxy_gb_abs.xlsx')

        summary_report_log['group_by_proxy generated buckets for ABS'] = df_proxy_gb_abs.shape[0]

        if print_steps:
            print('>>    Mapping missing values per proxy')
        minimum_observations=3
        max_iter=5

        if type(percentile_level)==float or type(percentile_level)==int:
            fields_map = {'avg_daily_traded_volume': 'avg_daily_traded_volume_P'+str(int(percentile_level*100))}
        elif percentile_level is None:
            fields_map = {'avg_daily_traded_volume': 'avg_daily_traded_volume_mean'}
        # Marcamos el mínimo para que se aplique un proxy en bonos
        summary_report_log['Observaciones minimas para aplicar proxy en ABS'] = minimum_observations
        summary_report_log['Columnas proxeadas en ABS'] = ', '.join([':'.join([key, item]) for key, item in zip(fields_map.keys(), fields_map.values())])
        df_price_abs_volume = aplica_proxies(df=df_price_abs, df_proxy=df_proxy_gb_abs, fields_map=fields_map, path_input=path_read, file_names=files, instrument='abs fallback', 
                                             minimum_observations=minimum_observations, max_iter=max_iter)
        df_price_abs_volume=df_price_abs_volume.copy()
        
        if type(percentile_level)==float or type(percentile_level)==int:
            fields_map = {'vola': 'vola_P'+str(int(percentile_level*100))}
        elif percentile_level is None:
            fields_map = {'vola': 'vola_mean'}
        # Marcamos el mínimo para que se aplique un proxy en bonos
        summary_report_log['Observaciones minimas para aplicar proxy en ABS'] = minimum_observations
        summary_report_log['Columnas proxeadas en ABS'] = ', '.join([':'.join([key, item]) for key, item in zip(fields_map.keys(), fields_map.values())])
        df_price_abs_vola = aplica_proxies(df=df_price_abs, df_proxy=df_proxy_gb_abs, fields_map=fields_map, path_input=path_read, file_names=files, instrument='abs fallback', 
                                           minimum_observations=minimum_observations, max_iter=max_iter)
        
        df_price_abs=df_price_abs_volume.merge(df_price_abs_vola, on=['ISIN', 'currency', 'AC_price', 'notional', 'exchange_rate', 'exception', 'market_percentaje_santander',
                                                                      'RATING_AC', 'instrument_type', 'industry', 'maturity', 'RATING_AC_original', 'Bucket'])
        # df_price_abs=df_price_abs.rename(columns={'base_currency_x':'base_currency','key_x':'key_volume', 'proxy_aplicado_x':'proxy_aplicado_volume', 'modified_key_x':'modified_key_volume', 'key_y':'key_vola', 
        #                                             'proxy_aplicado_y':'proxy_aplicado_vola', 'modified_key_y':'modified_key_vola', 'vola_y':'vola', 'avg_daily_traded_volume_x':'avg_daily_traded_volume', 'base input price_x': 'base input price'})
        # df_price_abs=df_price_abs.drop(columns=['base_currency_y','avg_daily_traded_volume_y', 'vola_x', 'base input price_y'])
        df_price_abs=df_price_abs.rename(columns={'Issuer_x':'issuer','base_currency_x':'base_currency','key_x':'key_volume', 'proxy_aplicado_x':'proxy_aplicado_volume', 
                                                  'modified_key_x':'modified_key_volume', 'key_y':'key_vola', 'proxy_aplicado_y':'proxy_aplicado_vola', 
                                                  'modified_key_y':'modified_key_vola', 'vola_y':'vola', 'avg_daily_traded_volume_x':'avg_daily_traded_volume', 
                                                  'issuer_proxy_aplicado_x':'issuer_proxy_aplicado', 'base input price_x':'base input price'})
        df_price_abs=df_price_abs.drop(columns=['base_currency_y', 'avg_daily_traded_volume_y', 'vola_x', 'base input price_y'])


        # Ahora modificamos manualmente los datos del average daily traded volume que han sido inputados por ISIN en el fichero.																												
        if print_steps:
            print('>    Including (if any) the user defined input volumes for the bond portfolio')
        files_modificacion={'manual changes': dict_files['ABS user inputted changes']}
        df_price_abs, df_manual_abs = fri.aplica_inputs_manuales(path_read=path_read, files_modificacion=files_modificacion, df=df_price_abs, product='ABS', path_write=path_write, 
                                                  tc=tc, base_currency=base_currency)
        
    if abs_included:
        if print_steps:
            print('>  Calculating ABS concentration AVA')
    
        days_threshold=10
        all_same_currency=True
        df_abs_AVA = ava.ajuste_AVA(exchange_rates=tc, df=df_price_abs, param_y=param_y, epsilon=epsilon, days=days_threshold, 
                                all_same_currency=all_same_currency, execution_date=execution_date)
        
        # # Renombramos la columna de nominal, para aclarar que el output se presenta en €
        # df_abs_AVA=df_abs_AVA.rename(columns={"notional": f"notional_{base_currency}"})
    
        # Separamos aquellos ISIN donde no tenemos divisa o dato de AC. En caso de que no haya número de ISIN también es separado. 
        df_abs_AVA_warning=df_abs_AVA[df_abs_AVA['currency'].isnull() | df_abs_AVA['AC_price'].isnull() | df_abs_AVA['ISIN'].isnull()]
    
        if len(df_abs_AVA_warning)>1:
            print(f'-·-> ATTENTION: There are {len(df_abs_AVA_warning)} underlyings without ISIN, currency or AC price')
            df_abs_AVA_warning=df_abs_AVA_warning[['ISIN', 'currency', 'AC_price']]
            print_output(dataframe=df_abs_AVA_warning, path_write=path_write, file_name='ABS_missing_values.xlsx')  
        elif len(df_abs_AVA_warning)==1:
            print(f'-·-> ATTENTION: There is {len(df_abs_AVA_warning)} underlying without ISIN, currency or AC price')
            df_abs_AVA_warning=df_abs_AVA_warning[['ISIN', 'currency', 'AC_price']]
            print_output(dataframe=df_abs_AVA_warning, path_write=path_write, file_name='ABS_missing_values.xlsx') 
        else:
            df_abs_AVA_warning=df_abs_AVA_warning[['ISIN', 'currency', 'AC_price']]
            print_output(dataframe=df_abs_AVA_warning, path_write=path_write, file_name='ABS_missing_values.xlsx') 
        
        df_abs_AVA=df_abs_AVA[df_abs_AVA['currency'].notnull() & df_abs_AVA['AC_price'].notnull() & df_abs_AVA['ISIN'].notnull()]
    
        if print_steps:
            print(f'\n-·-> Concentration AVA for ABS portfolio: {df_abs_AVA.concentration_AVA.sum():,.2f}')
        summary_report_log['Ajuste AVA por concentracion en ABS'] = df_abs_AVA.concentration_AVA.sum()

        if print_out:
            # df_abs_AVA=df_abs_AVA.rename(columns={'Nominal':''})
            df_abs_AVA.drop(columns=['exchange_rate', 'currency', 'concentration_AVA_native_currency'], inplace=True)
            df_abs_AVA_resumen = df_abs_AVA[['ISIN', 'notional', 'AC_price', 'avg_daily_traded_volume', 'exception', 'market_percentaje_santander',
                                             'base_currency', 'vola', 'porcent_santander_daysthreshold', 'non_concentrated_notional', 'concentrated_notional',
                                             'prudent_price', 'concentration_AVA']].copy()
            print_output(dataframe=df_abs_AVA, path_write=path_write, file_name='df_abs_AVA.xlsx')
            print_output(dataframe=df_abs_AVA_resumen, path_write=path_write, file_name='df_abs_AVA_summary.xlsx')
    
        df_marginal_distribution_abs = fri.read_file(path_read, dict_files['marginal distribution ABS'])    
        df_marginal_distribution_abs.drop(columns=['FVA dist', 'FVA All dist'], inplace = True)
        df_marginal_distribution_abs.rename(columns = {'Sum of Nominal Vivo': 'Nominal Vivo'}, inplace=True)
        
        keep_columns_abs = ['ISIN', df_marginal_distribution_abs.columns[1], 'notional']
        df_manual_abs = df_manual_abs.loc[:, keep_columns_abs]
        df_manual_abs.rename(columns={'notional': 'Nominal Vivo'}, inplace = True)
        df_marginal_distribution_abs = df_marginal_distribution_abs.append(df_manual_abs)
       
        df_abs_AVA_distributed = ava.distribute_adjustment(df_abs_AVA, df_marginal_distribution_abs)

        print_output(dataframe=df_abs_AVA_distributed, path_write=path_write, file_name='df_abs_AVA_distributed.xlsx')

        summary_report_log['Ajuste AVA total'] = df_abs_AVA.concentration_AVA.sum() + df_bonds_AVA.concentration_AVA.sum()
    
        print('\n-----------------------------\n')

        print(f'-·->> Concentration AVA (complete): {(df_abs_AVA.concentration_AVA.sum() + df_bonds_AVA.concentration_AVA.sum()):,.2f}')
    
    # Vamos a hacer que esto se muestre siempre.
    df_summary_report_log = pd.DataFrame.from_dict(summary_report_log, orient='index', columns=['Status'])
    print_output(dataframe = df_summary_report_log, path_write=path_write, file_name='summary_report_log.xlsx', print_index=True)
    
    # Renombramos la columna de nominal, para aclarar que el output se presenta en €
    # df_bonds_AVA=df_bonds_AVA.rename(columns={'notinal':'notionalEUR'})
    # df_abs_AVA=df_abs_AVA.rename(columns={'notional':'notionalEUR'})
    
    if abs_included: 
        return df_bonds_AVA, df_abs_AVA, summary_report_log
    
    return df_bonds_AVA, summary_report_log
  

if __name__ == '__main__' :
    import inspect
    master_path='\\'.join(inspect.getfile(do).split('\\')[:-1])
    tool_parameters='tool_parameters_Concentration_BR.xlsx'
    out_bonds, out_abs, summary_report_log = do(master_path, tool_parameters)
    # out_bonds, summary_report_log = do(master_path, tool_parameters)
