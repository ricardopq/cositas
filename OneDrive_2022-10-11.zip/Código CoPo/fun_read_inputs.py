# -*- coding: utf-8 -*-
"""
Created on Wed Jan 22 12:02:14 2020

@author: cdasi
"""

import pandas as pd
import numpy as np
from os.path import join, isfile
from os import listdir

import fun_volatilidad as vola
import do as do

def read_file(path, file, **kwargs):
    '''
    Funcion auxiliar empleada para leer ficheros tanto .xlsx como .csv con el paquete pandas.
    
    Parameters
    ----------
    path : String
        Directorio en el que se encuentra el fichero a leer
    file : String
        Nombre del fichero a leer.
    **kwargs :
        Parametros adicionales a pasar a los métodos de pandas read_csv o read_excel
    '''
    if file is None or pd.isna(file):
        return None
    elif file.lower().endswith(r'.xlsx') or file.lower().endswith(r'.xlsm'):
        return pd.read_excel(join(path, file), **kwargs)
    elif file.lower().endswith(r'.csv') or file.lower().endswith(r'.txt'):
        # Determinamos el separador automáticamente
        reader = pd.read_csv(join(path, file), sep=None, iterator=True, engine='python')
        inferred_sep = reader._engine.data.dialect.delimiter
        # Si se ha definido explícitamente un separador, usamos ese, si no el que ha decidido pandas
        kwargs['sep']=kwargs['sep'] if 'sep' in kwargs else inferred_sep
        # Si se ha definido explícitamente un engine, usamos ese, si no usamos "python" para csv
        kwargs['engine']=kwargs['engine'] if 'engine' in kwargs else 'python'
        return pd.read_csv(join(path, file), **kwargs)
    else:
        raise NameError(f'Formato de fichero del fichero "{file}" no reconocido.')

def read_portfolio(path_read, df_volume, tc, base_currency, bond_volume_currency, abs_volume_currency, base_input_price, files, default_market_percentaje, abs_included, print_steps, path_write):
    '''
    Within this function, the bond and ABS portfolio is read.
    
    Parameters
    ----------
        path_read : String
            From where the files required are read.
        df_volume : Pandas dataframe
            Dataframe containing the avereage traded volume for bonds and ABS.
        tc : Dictionary
            Containing the exchange rates versus a master currency.
        files : Dictionary
            With keys portfolio, excepciones, porcentajes and perimetro_bonos, representing the file where the portfolio is
            loaded (with two sheets, 'bonos' and 'abs', one for each instrument), the file with the ISINs not to consdier in the
            calculus, the desk access percentajes and the desks which are included in the calculation respectively.
        default_market_percentaje : Float
            Default market percentaje in case any is not informed.
        print_steps : Bloolean
            Whether to print or not the different steps given by the model.
    
    Returns
    -------
        df_portfolio_bonds : Pandas dataframe
            The bond porfolio after which the concentration AVA will be calculated
        df_portfolio_abs : Pandas dataframe
            The abs porfolio after which the concentration AVA will be calculated

    '''
    # Portfolio file ABS
    if abs_included:
        file_portfolio_abs = files['portfolio abs']
        # ABS. Leemos el fichero, renombramos columnas, generamos la columna 'instrument' y añadimos el daily traded volume por ISIN
        df_portfolio_ABS = read_file(path_read, file_portfolio_abs)
        # Me quedo con los de all desks sino esta repetido
        df_portfolio_ABS=df_portfolio_ABS.loc[df_portfolio_ABS.desk.eq('ALL_DESKS')]
        df_portfolio_ABS=df_portfolio_ABS.groupby(['ISIN', 'currency', 'Precio_AC'], as_index=False)['Sum of Nominal Vivo'].sum()
        df_portfolio_ABS=df_portfolio_ABS.rename(columns={'currency':'currency', 'Sum of Nominal Vivo':'notional', 'Precio_AC':'AC_price'})
        df_portfolio_ABS['base input price'] = base_input_price
        # df_portfolio_ABS.loc[:, 'instrument'] = np.where(df_portfolio_ABS.portfolio.apply(lambda x: 'abs' in x.lower()), 'ABS', 'Bond')
        df_portfolio_ABS = pd.merge(df_portfolio_ABS, df_volume[['ISIN', 'avg_daily_traded_volume']], how='left', on='ISIN')

        df_portfolio_ABS.loc[:, 'notional'] = df_portfolio_ABS.loc[:, 'notional'] / df_portfolio_ABS.loc[:, 'currency'].map(tc)
        df_portfolio_ABS['exchange_rate'] = df_portfolio_ABS.currency.map(tc)
        # df_portfolio_ABS.loc[:,'avg_daily_traded_volume']=df_portfolio_ABS.avg_daily_traded_volume / df_portfolio_ABS.exchange_rate
        if abs_volume_currency=='native':
            df_portfolio_ABS.loc[:, 'avg_daily_traded_volume'] = df_portfolio_ABS.loc[:, 'avg_daily_traded_volume'] / df_portfolio_ABS.loc[:, 'currency'].map(tc)
        else:
            df_portfolio_ABS.loc[:, 'avg_daily_traded_volume'] = df_portfolio_ABS.loc[:, 'avg_daily_traded_volume'] / tc[abs_volume_currency]
        
    #  Portfolio file Bonds
    file_portfolio_bonds = files['portfolio bond']
    file_static_bonds=files['bond_axis_data']
    
    
    # Añadimos el resultado de ejecutar bonos y ABS 
    df_portfolio_bonos = read_file(path_read, file_portfolio_bonds)

    # df_market_making=read_file(path_read, file_market_making)
    # Añadimos la columa market making para asignarles un 100% de acesso al mercado. 
    # mark_m_issuer = df_market_making[df_market_making.Fill.eq("issuer")]
    # mark_m_ISIN = df_market_making[df_market_making.Fill.eq("ISIN")]
    
    # df_portfolio_bonos.loc[:,'Market Making']=np.where(df_portfolio_bonos.ticker.isin(mark_m_ISIN.Value), 'Market Making', np.nan)
    # df_portfolio_bonos.loc[:,'Market Making']=np.where(df_portfolio_bonos.issuer.isin(mark_m_issuer.Value), 'Market Making', np.nan)
    

    df_portfolio_bonos=df_portfolio_bonos[['ticker', 'issuer', 'Currency', 'Nominal Vivo' , 'Area', 'Industry']]

    df_portfolio_bonos=df_portfolio_bonos.rename(columns={'ticker':'ISIN', 'Currency':'currency', 'Nominal Vivo':'notional', 'Area':'region'})
    df_ac_bonos=read_file(path_read, file_static_bonds)
    # Rellenamos la divisa con los datos del lago
    df_portfolio_bonos.currency.fillna(df_portfolio_bonos.ISIN.map(df_ac_bonos[['ISIN', 'currency']].set_index('ISIN').to_dict()), inplace=True)

    # Inlcuimos el precio de AC en el portfolio
    df_ac_bonos=df_ac_bonos[['ISIN', 'acprice']].rename(columns={'acprice':'AC_price'})
    df_portfolio_bonos=df_portfolio_bonos.merge(df_ac_bonos, how='left')    
    df_portfolio_bonos.drop_duplicates(inplace=True)
    df_portfolio_bonos['base input price'] = base_input_price
    
    # Bonos. Leemos el fichero, renombramos columnas, generamos la columna 'instrument' y añadimos el daily traded volume por ISIN
    df_portfolio_bonos = pd.merge(df_portfolio_bonos, df_volume[['ISIN', 'avg_daily_traded_volume']], how='left', on='ISIN')
    if bond_volume_currency=='native':
        df_portfolio_bonos.loc[:, 'avg_daily_traded_volume'] = df_portfolio_bonos.loc[:, 'avg_daily_traded_volume'] / df_portfolio_bonos.loc[:, 'currency'].map(tc)
    else:
        df_portfolio_bonos.loc[:, 'avg_daily_traded_volume'] = df_portfolio_bonos.loc[:, 'avg_daily_traded_volume'] / tc[bond_volume_currency]

    # El average daily traded volume lo pasamos de USD a EUR (lo leemos en USD), y el nocional de la divisa en la que esté a 
    # EUR
    df_portfolio_bonos.loc[:, 'notional'] = df_portfolio_bonos.loc[:, 'notional'] / df_portfolio_bonos.loc[:, 'currency'].map(tc)
    df_portfolio_bonos['exchange_rate'] = df_portfolio_bonos.currency.map(tc)


    # Hay una serie de bonos o instrumentos que podemos asignar un ajuste AVA = 0 independientemente de que estén o no
    # concentrados (por ser market makers, o por el motivo que se pueda justificar). Aquí leemos estos ISINs que vamos a
    # excluir del cálculo.
    excepciones=read_file(path_read, files['excepciones'])
    exclusiones=read_file(path_read, files['exclusiones'])
    
    df_portfolio_bonos.loc[:, 'exception'] = np.where(df_portfolio_bonos.ISIN.isin(excepciones.ISIN), True, False)
    df_portfolio_bonos=df_portfolio_bonos[~df_portfolio_bonos.ISIN.isin(exclusiones.ISIN)]
    
    if abs_included:
        df_portfolio_ABS.loc[:, 'exception'] = np.where(df_portfolio_ABS.ISIN.isin(excepciones.ISIN), True, False)  
        df_portfolio_ABS=df_portfolio_ABS[~df_portfolio_ABS.ISIN.isin(exclusiones.ISIN)]
        df_portfolio_ABS.loc[:, 'market_percentaje_santander']=1  #Por ser AB
        df_portfolio_ABS['base_currency'] = base_currency
    
    # Incluimos los porcentajes que tienea acceso cada mesa (que entendemos que es el portfolio), cargado en un fichero externo adicional.
    porcentajes=read_file(path_read, files['porcentajes'])
    
    dict_map={portfolio: percentaje for portfolio, percentaje in zip(porcentajes['Sector'], porcentajes['Market percentaje'])}
    # Diferenciamos entre los gobieros europeos y los no europeos 
    df_portfolio_bonos.loc[:,'Industry']=np.where(df_portfolio_bonos.currency.eq('EUR') & df_portfolio_bonos.Industry.eq('Governments'), df_portfolio_bonos.Industry+' EUR', df_portfolio_bonos.Industry)
    # Diferenciamos entre los españoles y los no españoles
    df_portfolio_bonos.loc[:,'Industry']=np.where(df_portfolio_bonos.currency.eq('EUR') & df_portfolio_bonos.Industry.eq('Governments EUR') & df_portfolio_bonos.ISIN.str.startswith('ES'), 'SPGB', df_portfolio_bonos.Industry)
    # En caso de que algún bono no tenga información referente a "Industry" lo catalogaremos como "Others". 
    # Se generará un aviso y un output alertando de la situación e informando de los bonos en los que sucede. 
    if len(df_portfolio_bonos[df_portfolio_bonos.Industry.isna()])>0:
        print(f'-·-> ATTENTION: There are {len(df_portfolio_bonos[df_portfolio_bonos.Industry.isna()])} ISIN with no Industry data')
        df_ISIN_incomplete=df_portfolio_bonos[df_portfolio_bonos.Industry.isna()][['ISIN']]
        do.print_output(dataframe=df_ISIN_incomplete, path_write=path_write, file_name='Bonds_missing_Industry.xlsx')  
        df_portfolio_bonos.loc[:,'Industry']=np.where(df_portfolio_bonos.Industry.isna(), 'Others', df_portfolio_bonos.Industry)
    df_portfolio_bonos.loc[:, 'market_percentaje_santander']=df_portfolio_bonos.Industry.map(dict_map)
    df_portfolio_bonos['base_currency'] = base_currency
    
    # Introducimos un market percentaje del 100%  para aquellos en los que el banco es market maker 
    # df_portfolio_bonos.loc[:,'market_percentaje_santander']=np.where(df_portfolio_bonos['Market Making'].eq('Market Making'), 1, df_portfolio_bonos.market_percentaje_santander)

    # Aplicamos los tipos de cambio a los volumenes
    # df_portfolio_bonos.loc[:,'avg_daily_traded_volume']=df_portfolio_bonos.avg_daily_traded_volume / df_portfolio_bonos.exchange_rate
    
    if abs_included:
        return df_portfolio_bonos, df_portfolio_ABS
    
    
    return df_portfolio_bonos


def read_volume(path_read_main, volume_files, abs_included, print_steps=True):
    '''
    With this file we load to the main function the dataframes which will be used later on to proceed with the calculus
    
    Parameters
    ----------
        path_read : String
            Path where the volume files are saved. File names are automatically generated.
        volume_files : Dictionary
            With keys 'bonds' and 'abs', referencing to the files to read from in case reload_df_volume=True or the files in
            which to save the output when save_df_volume=True
        print_steps : Boolean, default True
            Prints given steps through the functions if True
    Returns
    -------
        df_volume : Pandas dataframe
            Dataframe with two columns, the ISIN and the avg traded
            ...
    '''
    if print_steps:
        print('>  Reading bond volume file')
    file_volume = volume_files['bonds']
    df_volume_bonos = read_file(path_read_main, file_volume)

    if abs_included:
        if print_steps:
            print('>  Reading ABS volume file')
        file_volume = volume_files['abs']
        df_volume_abs = read_file(path_read_main, file_volume)
        df_volume = pd.concat([df_volume_bonos, df_volume_abs], sort=False)
    else:
        df_volume=df_volume_bonos.copy()
    
    return df_volume


def read_markit_price(path_read, print_steps):
    
    # Markit file
    file_markit = r'Santander_N1600_30SEP2019.csv'
    if print_steps:
        print('Leyendo fichero de precio Markit: %s' % file_markit)
    cols_price = ['Date', 'ISIN', 'Bid Price', 'Mid Price', 'Ask Price']
    df_price_markit = read_file(path_read, file_markit, sep = ',', decimal = '.', usecols = cols_price)
    
    return df_price_markit


def load_volatility(path_read, vola_files, abs_included, print_steps):
    
    if print_steps:
        print('>  Reading bond volatility file')
    df_vola_bonds=read_file(path_read, vola_files['bonds'])
    
    if abs_included:
        if print_steps:
            print('>  Reading ABS volatility file')
        df_vola_abs=read_file(path_read, vola_files['abs'])
        # Las volatilidades de ABS están anualizadas, las convertimos a diarias
        df_vola_abs.loc[:,'volatility']=df_vola_abs.volatility / np.sqrt(250/12)
        df_volatility=pd.concat([df_vola_bonds, df_vola_abs])
    else:
        df_volatility=df_vola_bonds.copy()
    
    df_volatility.rename(columns={'volatility': 'vola'}, inplace=True)
        
    return df_volatility


# def generate_volatility(path_read, execution_date, vola_files, volatility_timewindow, end_of_month_vola=True, days_in_year=250, custom=True,
#                         save_output=False, print_steps=True):
    
#     '''
#     Function where the volatility of the instruments is calculated when information is available.
    
#     Parameters
#     ----------
#         path_read : String
#             From where to read and write the files used and generated in this function (if parametrized as so)
#         execution_date : datetime object
#             Date in which the model is executed
#         vola_files : Dictionary
#             With keys bonds, abs, bonds_write and abs_write, representing the file containing the historical series prices 
#             of bonds, the file containing the historical series prices of abs, the name of the file in which to load the 
#             bond calculated information and the name of the file in which to load the ABS calculated data.
#         volatility_timewindow : Integer
#             Number of days to consider for generating the volatility
#         end_of_month_vola : Boolean, default True
            
    
#     Returns
#     -------
    
#     '''
    
#     # Monthly historical information file (for volatility calculation)
#     if print_steps:
#         print('Leyendo fichero de precios historicos de bonos: %s' % vola_files['bonds'])
#     df_historical_bonds = read_file(join(path_read, vola_files['bonds']))
#     df_historical_bonds.drop(columns=['ADO AC', 'FI-ISIN'], inplace = True)
#     if print_steps:
#         print('Leyendo fichero de precios historicos de ABS: %s' % vola_files['abs'])
#     df_historical_abs = read_file(join(path_read, vola_files['abs']))
    
#     if not custom:
#         if end_of_month_vola:
#             df_historical_bonds.columns = pd.to_datetime(df_historical_bonds.columns, errors = 'ignore')
#             df_historical_abs.columns = pd.to_datetime(df_historical_abs.columns, errors = 'ignore')
    
#             # Lo hacemos así porque queremos usar la mayor cantidad de datos. Si para bonos tenemos más ventana que para ABS,
#             # ya que por ejemplo hay un mes de datos que nos falta en ABS pero no en bonos, pues bonos usará una cantidad de datos
#             # para generar la volatilidad mayor que ABS
#             end_of_month_dates = pd.to_datetime(pd.date_range(end = execution_date, periods=12, freq='BM'))
#             if print_steps:
#                 print('Generando volatilidad de bonos')
#             df_volatility_bonds = vola.volatility(df_historical_bonds, volatility_timewindow, considered_dates=end_of_month_dates)
#             if print_steps:
#                 print('Generando volatilidad de ABS')
#             df_volatility_abs = vola.volatility(df_historical_abs, volatility_timewindow, considered_dates=end_of_month_dates)
            
#             # Multiplicamos por sqrt(1/250 / 1/12) ya que este es el factor corrector que aplicamos por el tiempo considerado cuando es anual
#             # para pasarlo a diario.
#             # Lógica:
#             #   Precios mensuales -> Serie de renimientos mensuales -> Std mensual
#             #   * Como el modelo que asumimos es normal, tenemos que el factor VARIANZA es lineal en el tiempo, por tanto,
#             #   Std mensual * sqrt(12) = Std anual -> Std anual * sqrt(1/250) = Std diaria
#             df_volatility_bonds.loc[:, 'vola'] = df_volatility_bonds.loc[:, 'vola'] * np.sqrt(12 / days_in_year)
#             df_volatility_abs.loc[:, 'vola'] = df_volatility_abs.loc[:, 'vola'] * np.sqrt(12 / days_in_year)
    
#         else:
#             if print_steps:
#                 print('Generando volatilidad de bonos')
#             df_volatility_bonds = vola.volatility(df_historical_bonds, volatility_timewindow)
#             if print_steps:
#                 print('Generando volatilidad de ABS')
#             df_volatility_abs = vola.volatility(df_historical_abs, volatility_timewindow)
            
#             # Aquí no dividimos ni multiplicamos por nada porque ya tenemos rendimientos diarios, y por tanto std diaria.
#     else:
#         # Custom es, bonos anual y la otra mensual
#         if print_steps:
#             print('Generando volatilidad de bonos')
#         df_volatility_bonds = vola.volatility(df_historical_bonds, volatility_timewindow)
        
#         df_historical_abs.columns = pd.to_datetime(df_historical_abs.columns, errors = 'ignore')
        
#         # Lo hacemos así porque queremos usar la mayor cantidad de datos. Si para bonos tenemos más ventana que para ABS,
#         # ya que por ejemplo hay un mes de datos que nos falta en ABS pero no en bonos, pues bonos usará una cantidad de datos
#         # para generar la volatilidad mayor que ABS
#         end_of_month_dates = pd.to_datetime(pd.date_range(end = execution_date, periods=12, freq='BM')).strftime("%Y-%m-%d %H:%M:%S").tolist()
#         # Hardcodeamos volatility_timewindow a 12 ya que tenemos observaciones mensuales. Una ventana de 12 es todo un año de 
#         # observaciones.
#         volatility_timewindow=12
#         if print_steps:
#             print('Generando volatilidad de ABS')
#         df_volatility_abs = vola.volatility(df_historical_abs, volatility_timewindow, considered_dates=end_of_month_dates)
#         df_volatility_abs.loc[:, 'vola'] = df_volatility_abs.loc[:, 'vola'] * np.sqrt(12 / days_in_year)

        
        
#     df_volatility = pd.concat([df_volatility_bonds, df_volatility_abs])
#     df_volatility.drop_duplicates(subset='ISIN', inplace=True)
    
#     if save_output:
#         if print_steps:
#             print('Guardando fichero generado de volatilidad para bonos')
#         df_volatility_bonds.to_excel(join(path_read, vola_files['bonds_write']), index=False)
#         if print_steps:
#             print('Guardando fichero generado de volatilidad para abs')
#         df_volatility_abs.to_excel(join(path_read, vola_files['abs_write']), index=False)

        
#     return df_volatility

def aplica_inputs_manuales(path_read, path_write, files_modificacion, df, product, tc, base_currency, print_steps=True):
        
    df_modif = read_file(path_read, files_modificacion['manual changes']) 
    df_modif = df_modif.fillna('Not informed')
        
    
    # Mapeamos las columnas a modificar en el dataframe original con las columnas homólogas en el dataframe de inputs manuales
    dict_columns = {'avg_daily_traded_volume': 'Traded volume',
                    'market_percentaje_santander': 'Market percentaje',
                    'notional': 'Notional',
                    'vola': 'Volatility',
                    'AC_price': 'Reference price',
                    'currency': 'Currency'}
    
    # Checkearemos si el ISIN del dataframe de inputs manuales está o no en el dataframe original.
    #   - Si está, solo modificaremos en el dataframe original aquellos valores que vienen informados en el dataframe de inputs manuales.
    #   - Si no está, incluiremos todos los datos del ISIN nuevo. ¡Ojo que se generarán NaNs en el resto de columnas que no vienen informadas en el dataframe de inputs manuales!
    df_to_control_output = pd.DataFrame(columns=df_modif.columns)
    #En caso de que no haya ningun bono en el output que se toma de bonos asumimos que el usuario quiere solo ejecutar con inputs manuales
    if df.empty:
       mapper = {v:k for k,v in dict_columns.items()}
       df_modif.rename(columns=mapper, inplace=True)
       df_modif_gb = df_modif.groupby(['ISIN'], as_index=False).agg({'notional': 'sum', 'avg_daily_traded_volume': 'first', 'market_percentaje_santander': 'first', 'vola': 'first',  'currency': 'first', 'AC_price': 'first', 'base input price': 'first'}) 
       df_modif_gb.avg_daily_traded_volume=df_modif_gb.avg_daily_traded_volume / df_modif_gb.currency.map(tc)
       df_modif_gb.notional=df_modif_gb.notional / df_modif_gb.currency.map(tc)
       df_modif_gb=df_modif_gb.assign(base_currency=base_currency)
       df_modif_gb['exchange_rate']=df_modif_gb.currency.map(tc) #Columna necesaria para calculo de ajuste
       df_modif_gb['exception']=False  #Asumimos que no van a aplicar exenciones sobre el fichero de inputs manuales
       
       return df_modif_gb, df_modif
   
    if df_modif.empty:
        df_modif_m = df_modif.copy()
    else:
        for (isin), df_modif_m in df_modif.groupby(['ISIN']):
            
            # Si el ISIN no está en nuestro dataframe original, lo añadimos
            if not df.ISIN.eq(isin).any():
                # Primero checkeamos que no falte ningún tipo de información en el dataframe de inputs manuales, y luego añadimos la información
                if df_modif_m.isna().any(None):
                    df_to_control_output = df_to_control_output.append(df_modif_m, ignore_index=True)
                    continue
                
                else:
                    mapper = {v:k for k,v in dict_columns.items()}
                    df_modif_m.rename(columns=mapper, inplace=True)
                    #Agrupamos por ISIN por si tenemos niveles de distribución distintos para un mismo ISIN para realizar el cálculo agregado. 
                    #El nocional se suma pero el resto de campos deberían de ser iguales y por tanto tomamos el primero
    
                    df_modif_gb = df_modif_m.groupby(['ISIN'], as_index=False).agg({'notional': 'sum', 'avg_daily_traded_volume': 'first', 'market_percentaje_santander': 'first', 'vola': 'first',  'currency': 'first', 'AC_price': 'first', 'base input price': 'first'}) 
                    # Aplicamos el tipo de cambio donde es necesario
                    df_modif_gb.avg_daily_traded_volume=df_modif_gb.avg_daily_traded_volume / df_modif_gb.currency.map(tc)
                    df_modif_gb['exchange_rate']=df_modif_gb.currency.map(tc)
                    df_modif_gb.notional=df_modif_gb.notional / df_modif_gb.currency.map(tc)
                    df_modif_gb=df_modif_gb.assign(base_currency=base_currency)
                    
                    df = df.append(df_modif_gb)
            
            # En caso de que esté, modificamos los valores de aquellas columnas que vienen informadas en el dataframe de inputs manuales
            else:
                df_modif_gb = df_modif_m.groupby(['ISIN'], as_index=False).agg({'Notional': 'sum', 'Traded volume': 'first', 'Market percentaje': 'first', 'Volatility': 'first',  'Currency': 'first', 'Reference price': 'first'}) 
                original_row=pd.Series(df.loc[df.ISIN.eq(isin), dict_columns.keys()].values[0], index=dict_columns.values())
                df.loc[df.ISIN.eq(isin), dict_columns.keys()]=df_modif_gb.loc[:, dict_columns.values()].where(~df_modif_gb.loc[:, dict_columns.values()].eq('Not informed'), np.nan).fillna(original_row).values
                
    do.print_output(dataframe=df_to_control_output,
                    path_write=path_write,
                    file_name=f"inputs_manuales_incompletos_{product}.xlsx")
    
    # Rellenamos la columna de excepciones con False, para que luego en el cálculo de los ajustes no dé errores
    df.exception.fillna(False, inplace=True)
    df.reset_index(inplace=True)
    
    return df, df_modif_m 
    
    
    
    
    
    
    
    
    
    