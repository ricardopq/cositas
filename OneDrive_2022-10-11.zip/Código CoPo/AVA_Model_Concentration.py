# -*- coding: utf-8 -*-
"""
Main module for executing the Concentrated positions model. The model must be executed from this file, and the files and other
modules will be called when required.

The inputs are defined within this module, and the main function of do.py module executed. No value needs to be updated 
within this file, besides the tool parameters Excel spreadsheet name if changed.

For more detail regarding the model execution, please refer to its own documentation.


Created on Tue Oct  6 13:21:37 2020

@author: cdasi
"""

from do import do
import inspect

# Directorio donde está situado el código
master_path='\\'.join(inspect.getfile(do).split('\\')[:-1])
# Nombre del fichero de parametrización
tool_parameters=r'tool_parameters_Concentration_BR.xlsx'

if __name__ == '__main__':
    
    out=do(master_path, tool_parameters)
    a=13