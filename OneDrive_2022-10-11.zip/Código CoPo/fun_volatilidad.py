import numpy as np
import pandas as pd
import fun_read_inputs as fri

def volatility(df, n, considered_dates=[], skipna=True, interpolate_corrupt_values=False, delete_corrupt_returns=True):
    '''
    This function calculates the std of the continuous returns ( ln(D_t/D_{t-1}) ) of a given dataframe.
    
    Parameters
    ----------
        df : Pandas dataframe 
            Indicating where the indexes are ISINs, and the columns are the different dates in descending order from
            left to right in which the price of each ISIN is observed.
        n : Integer
            Number of dates to consider.
        considered_dates : List, default []
            IF a series of dates should be considered in the dataframe, or not. The column names must be datetime.datetime dates.
        skipna : Boolean, default True
            Wether to skip the NaN values or not for calulating the volatility
        interpolate_corrupt_values : Boolean, default True
    
    Return
    ------
        df_volatilidad. Pandas dataframe 
            With the ISINs as index and one column representing the calculated std
    '''
    
    df_ = df.copy()
    df_.set_index('ISIN', inplace=True, drop=True)
    
    if considered_dates:
        
        if sum([date in df_.columns for date in considered_dates]) != len([date in df_.columns for date in considered_dates]):
            # Este condicional es un operador .all() para listas. La lógica es, si todo son True, la suma será igual a la longitud. 
            # Si hay un False, tenemos que la suma será menor, y por tanto SI entraremos.
            print('Cuidado, las fechas de fin de mes que se han generado no coinciden con las del fichero. Revisa las fechas fin de mes' + 
                  'cargadas en el fichero de precios y las generadas automaticamente en el código. Las columnas que hay en el fichero' + 
                  'son las siguientes:')
            print(df_.columns)
            print('y las fechas que se han generado de final de mes las siguientes:')
            print(considered_dates)
        df_.columns = df_.columns.astype("str")     
        df_ = df_.loc[:, [col for col in considered_dates if col in df_.columns]]
        
    df_ = df_.iloc[:, :n]
    
    if interpolate_corrupt_values:
        print('>    Sustituimos los ceros por valores inteprolados entre los dos datos mas proximos')
        df_no_zeros = df_.replace(to_replace=0, value=np.nan)
        df_full = df_no_zeros.interpolate(method='linear', axis=1)
        df_rend = pd.DataFrame(np.log(df_full.div(df_full.shift(-1,axis=1))))
    
    if delete_corrupt_returns:
        df_rend = pd.DataFrame(np.log(df_.div(df_.shift(-1,axis=1))))
        df_rend.replace([np.inf, -np.inf], np.nan, inplace=True)
    
    # Al calcular los rendimientos con n fechas, obtenemos n-1 valores. Por tanto, como sabemos que es el último valor el que no va 
    # a estar completo, lo quitamos para la std.
    df_volatilidad = df_rend.iloc[:, :-1].std(axis = 1, skipna=True, ddof=1)
    
    out_df = pd.DataFrame({'ISIN':df_volatilidad.index, 'vola':df_volatilidad})
    out_df.reset_index(level=0, inplace=True, drop=True)
    
    return out_df

if __name__ == '__main__':
    file = r'C:\Users\cdasi\Documents\FVA AVA\03. Proyectos\04. Bonos y ABS\03. Concentracion\Codigo\Input\Volatilidad_bonos_anual.xlsx'

    df= fri.read_file(file)
    df.drop(columns=['ADO AC', 'FI-ISIN'], inplace = True)
        
    df_vola = volatility(df, 22)
